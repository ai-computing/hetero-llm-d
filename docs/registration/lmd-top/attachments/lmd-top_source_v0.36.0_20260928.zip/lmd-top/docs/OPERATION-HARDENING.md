# Operation correctness changes — 2026-09-28

These changes are in the working source tree, not a published release. They have
been checked offline; no cluster objects, NPU builds or routing policies were changed.

## Execution history

New compile/prefetch records use `job:<namespace>/<name>/<uid>` as the ID. The UID
identifies the Kubernetes execution across deletion/recreation and clusters. Old
name-only records remain readable. The first observation of a still-visible old
Job may produce one UID-based record as well. Logs are associated with owner UID,
not Pod-name prefixes. Missing UIDs are not persisted as ambiguous executions.

## Routes

Deleting a selected path preserves the other matches in its rule. Retargeting a
path splits a shared rule and retains rule filters and backend weight. Multiple
backends, duplicate paths across rules and ambiguous Service ports require an
explicit HTTPRoute edit. Target resources are read live. The final replacement
retains resourceVersion and is server-validated; a concurrent edit produces a
conflict. The operator must still check the route's Accepted/ResolvedRefs status
and traffic after a change: API acceptance is not traffic validation.

## Endpoint exclusion

The action changes labels used by matching Services and InferencePools, after
reading live selectors. It checks Service EndpointSlice removal and attempts to
restore labels if verification fails. Unsupported selector expressions and
unreadable routing resources stop the operation. Original values are retained in
`lmd-top.io/drain-original-labels`; restore those exact values before removing the
annotation when undoing a successful exclusion. Do not blindly undo after an
external label change: recovery is conditional on Pod UID and changed values.

This is routing-selector exclusion, not proof of finished streams. It does not
verify an EPP's internal cache, direct Pod-IP traffic or all existing connections,
and never automatically deletes a drained Pod. Confirm propagation and stream
completion independently before deletion. Changing an owning ReplicaSet selector
label can cause a replacement Pod to be created.

## Compilation and publication

New artifact paths append a stable fingerprint of the model/vendor and all compile
form fields. The suffix is not a content checksum or a full toolchain fingerprint:
externally supplied compiler images, passthrough environment and mutable model
revisions are not captured by it. Existing published paths cannot be overwritten;
move a build explicitly or use a different configuration before rebuilding it.
Old paths remain deployable from the store or via an explicit mount override. A
headless deployment with an inferred default path now targets the new layout.

Recipes copy finished outputs into a hidden sibling staging directory, then rename
on the store filesystem. A publication lock prevents cooperating publishers from
racing. On failure, no partial destination is exposed. An abrupt container kill can
leave hidden `.lmd-staging-*` / `.lmd-publish-*.lock` entries. Inspect the owning Job
and confirm no publisher is running before manually removing those leftovers.
Atomic rename semantics on the actual SMB/storage backend still need E2E validation.

Re-application performs server validation before deleting an old Job, refuses
pending/running Jobs, and stops on deletion failure. Multi-resource kubectl apply
is not transactional: a later API failure may still leave partial changes.

## Process/UI behavior

The shared runner bounds the complete kubectl process, writes stdin concurrently
with output reads and terminates/reaps the direct child on timeout. This does not
provide process-group termination for a detached credential-helper descendant.
Server dry-run uses the existing operation slot on a worker thread, leaving the UI
responsive and preventing another mutation until that operation completes.
