# lmd-top 프로그램 등록용 소스 패키지

- 작성일: 2026-09-28
- 버전: Cargo.toml의 0.36.0, 현재 작업 소스 스냅샷(미커밋 개선 포함)
- 본체: Rust src/, 내장 Python·Shell recipe, 설치 스크립트
- 빌드 입력: Cargo.toml/Cargo.lock, 모델 catalog, 내장 리소스, 문서
- 테스트와 CI 설정을 포함하며, 외부 의존성은 lock 파일로 관리합니다.
- EPP 확장(Go) 소스도 포함합니다. 본체의 --policy 기능이 이 소스를 내장하므로
  Rust 본체를 빌드할 때에도 contrib/epp-score-observer/ 디렉터리가 필요합니다.
- target/, dist/, .git/, 로컬 kubeconfig·인증 설정·환경 파일은 포함하지 않습니다.

## 빌드 / 실행

```sh
cargo build --locked --release
./target/release/lmd-top --help
LMD_NS=llm-serving LMD_PROM=127.0.0.1:9090 ./target/release/lmd-top --mode observe
```

빌드에는 Rust/Cargo와 링커, 의존성을 받기 위한 네트워크 또는 Cargo 캐시가 필요합니다.
실제 조회에는 kubectl 및 유효한 kubeconfig, Kubernetes와 Prometheus 연결이 필요합니다.
상태를 변경하는 작업은 --mode와 별도 사용자 확인으로 제어됩니다.
Go 확장 이미지 빌드는 별도 Go/컨테이너 빌드 환경을 필요로 합니다.

## 등록 의뢰서의 소스 규모와 관계

의뢰서의 행 수·Byte는 Rust 본체, 내장 recipe, install.sh 69개 파일의 물리적 크기입니다.
이 압축본에는 재현 가능한 빌드를 위해 Go 확장, 테스트, catalog, 문서 등도 추가로 들어
있으므로 압축 해제 총용량·전체 파일 수는 의뢰서의 본체 산정값과 다릅니다.
파일별 무결성은 SOURCE-MANIFEST.sha256에서 확인할 수 있습니다.

## 검증 범위

원본 작업본의 Rust 테스트 255개, Python 테스트 8개, strict Clippy 및 포맷 검사 통과.
패키지 추출 후 cargo check --locked --offline을 별도 수행합니다.
실제 클러스터/NPU 변경 검증은 수행하지 않았습니다. 동봉 영상은 조회 전용 실행입니다.
