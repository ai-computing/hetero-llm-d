#!/usr/bin/env python3
"""Publish a complete build on the store filesystem without merging or overwriting.

Staging and locks are hidden siblings, excluded by the discovery CronJob's * glob.
A killed publisher may leave a hidden lock/staging directory for explicit recovery;
readers continue seeing either no build or the previously published complete build.
"""
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile


def publish(source, destination):
    source, destination = Path(source), Path(destination)
    parent = destination.parent
    parent.mkdir(parents=True, exist_ok=True)
    lock = parent / (".lmd-publish-" + destination.name + ".lock")
    # Atomic mkdir serializes cooperating publishers, also on the shared SMB mount.
    lock.mkdir()
    stage = None
    try:
        if destination.exists() or destination.is_symlink():
            raise FileExistsError(f"build already published: {destination}; move/delete explicitly before rebuilding")
        if not source.is_dir() or not any(source.iterdir()):
            raise ValueError("compiler produced no artifact")
        stage = Path(tempfile.mkdtemp(prefix=".lmd-staging-", dir=parent))
        shutil.copytree(source, stage, dirs_exist_ok=True)
        (stage / "lmd-build.json").write_text(json.dumps({
            "schema": "lmd-top/build/v1",
            "execution_uid": os.environ.get("LMD_BUILD_UID", ""),
            "target": destination.name,
            "model": os.environ.get("MODEL_ID", ""),
        }) + "\n")
        # Same-filesystem directory rename publishes all files together. Never fall back
        # to a copy into destination if this filesystem cannot perform the rename.
        stage.rename(destination)
        stage = None
    finally:
        if stage is not None:
            shutil.rmtree(stage, ignore_errors=True)
        lock.rmdir()


if __name__ == "__main__":
    publish(sys.argv[1], sys.argv[2])
    print("COMPILE_DONE", sys.argv[2], flush=True)
