# RBLN ahead-of-time compile (optimum-rbln). Mounted from a ConfigMap; all input via env.
#
#   MODEL_ID                    HF repo id or local path        (required)
#   OUTPUT                      destination in the model store  (required)
#   RBLN_NPU                    target chip                     (default RBLN-CA22)
#   RBLN_TENSOR_PARALLEL_SIZE   chip count                      (default 1)
#   RBLN_MAX_SEQ_LEN            compile-time context length     (default 4096)
#   RBLN_BATCH_SIZE             static batch size               (default 1)
#   RBLN_ATTN_IMPL              flash_attn | eager              (default flash_attn)
#   RBLN_KVCACHE_PARTITION_LEN  flash_attn only                 (default 16384)
import os
import shutil

# Report the toolchain before anything else. Compiles here failed for three different models
# across three parameter sets with the same opaque codegen error, and nothing surfaced that the
# host's transformers/torch had moved far ahead of optimum-rbln. lmd-top parses this line out of
# the log into its history, so a version skew shows up as a pattern instead of a mystery.
def _report_toolchain():
    import importlib.metadata as md

    parts = []
    for pkg in ("optimum-rbln", "rebel-compiler", "transformers", "torch"):
        try:
            parts.append(f"{pkg}={md.version(pkg)}")
        except Exception:
            parts.append(f"{pkg}=absent")
    print("LMD_TOOLCHAIN " + " ".join(parts), flush=True)

    # Compare what is installed against what the vendor SDK itself declares, rather than
    # against a compatibility matrix maintained by hand. optimum-rbln pins its dependencies
    # exactly, so this is a precise check — and it is the vendor's opinion, not ours.
    bad = []
    try:
        for req in md.requires("optimum-rbln") or []:
            spec = req.split(";")[0].strip()
            if "==" not in spec:
                continue
            name, want = (p.strip() for p in spec.split("==", 1))
            try:
                have = md.version(name)
            except Exception:
                continue
            # PEP 440: when the specifier carries no local label, the candidate's local
            # label is ignored — `torch 2.11.0+cpu` satisfies `==2.11.0`. Comparing the raw
            # strings reported three mismatches on a perfectly correct install.
            def _public(v):
                return v.split("+", 1)[0]

            if _public(have) != _public(want):
                bad.append(f"{name} {have} != required {want}")
    except Exception:
        pass
    if bad:
        print("LMD_DEPS_MISMATCH " + "; ".join(bad[:4]), flush=True)


_report_toolchain()


# Not viable, recorded so nobody retries it: rebel ships core_ori/ as plain source next to
# the frozen core, and compile_from_any resolves `compile` through a module global, so it looks
# rebindable. Importing it aborts — both register the same TVM operator attributes:
#
#   InternalError: Check failed: (p.second != plevel) is false: Attribute
#   target.rebel_descriptor of abs is already registered with same plevel=10
#
# Useful finding all the same: core_ori is a live implementation, not a stale snapshot, and
# librbln.so is a TVM build — which is why TVM's own TVM_LOG_DEBUG / TVM_BACKTRACE apply here.

from optimum.rbln import RBLNAutoModelForCausalLM as M

get = os.environ.get
output = os.environ["OUTPUT"]
local = "/work/out"

cfg = dict(
    rbln_npu=get("RBLN_NPU", "RBLN-CA22"),
    rbln_max_seq_len=int(get("RBLN_MAX_SEQ_LEN", "4096")),
    rbln_batch_size=int(get("RBLN_BATCH_SIZE", "1")),
)

# The kwarg naming the chip count differs across optimum-rbln versions: 0.11 takes
# `rbln_num_devices`, 0.10 takes `rbln_tensor_parallel_size`. Rather than keep a version
# matrix — which is the thing that keeps going wrong — ask the library: it rejects an
# unknown kwarg by name, so try the candidates and keep the one it accepts.
TP_KWARGS = ("rbln_tensor_parallel_size", "rbln_num_devices")
tp = int(get("RBLN_TENSOR_PARALLEL_SIZE", "1"))
# No default here. An absent RBLN_ATTN_IMPL means "do not set rbln_attn_impl at all" and let
# optimum-rbln choose — which is what the artifacts that work on this hardware were built
# with. Defaulting to flash_attn here silently re-added the flag after the manifest had
# deliberately omitted it: the default existed in two places and the recipe's copy won.
attn = get("RBLN_ATTN_IMPL", "")
if attn:
    cfg["rbln_attn_impl"] = attn
    # Partitioning is a flash_attn concept, so it only travels with an explicit choice.
    if attn == "flash_attn":
        cfg["rbln_kvcache_partition_len"] = int(get("RBLN_KVCACHE_PARTITION_LEN", "16384"))

# create_runtimes=False: compile without claiming a device, so serving may hold the chips.
def _from_pretrained(config):
    """Compile, choosing the tensor-parallel kwarg this optimum-rbln actually accepts."""
    last = None
    for name in TP_KWARGS:
        attempt = dict(config)
        attempt[name] = tp
        try:
            print(f"RBLN_CONFIG {attempt}", flush=True)
            return M.from_pretrained(
                os.environ["MODEL_ID"], export=True, rbln_create_runtimes=False, **attempt
            )
        except ValueError as exc:
            # Only a rejection of *this* kwarg justifies trying the next name; any other
            # ValueError is a real problem and must not be masked by a retry.
            if "Unexpected arguments" not in str(exc) or name.removeprefix("rbln_") not in str(exc):
                raise
            print(f"  {name} not accepted by this version, trying the next name", flush=True)
            last = exc
    raise last if last else RuntimeError("no tensor-parallel kwarg accepted")


try:
    model = _from_pretrained(cfg)
except Exception as exc:
    # rebel-compiler raises a bare RuntimeError from a frozen module, so the traceback alone
    # says only "Error occurred while compiling the model". Whatever detail exists lives in the
    # exception's args and cause chain; print it so the failure is reportable.
    import traceback

    print("LMD_COMPILE_ERROR", type(exc).__name__, repr(exc.args), flush=True)
    cause, depth = exc.__cause__ or exc.__context__, 0
    while cause is not None and depth < 5:
        print(
            "LMD_COMPILE_CAUSE",
            type(cause).__name__,
            repr(getattr(cause, "args", ())),
            flush=True,
        )
        cause, depth = cause.__cause__ or cause.__context__, depth + 1
    traceback.print_exc()
    raise
# Build into local scratch first — the shared store is SMB and rejects the compiler's I/O.
model.save_pretrained(local)

# Publish from a hidden sibling directory; never merge files into a serving build.
from importlib.util import spec_from_file_location, module_from_spec
_spec = spec_from_file_location("lmd_publish", "/scripts/publish-artifact.py")
_publisher = module_from_spec(_spec)
_spec.loader.exec_module(_publisher)
_publisher.publish(local, output)
print("COMPILE_DONE", os.listdir(output), flush=True)
