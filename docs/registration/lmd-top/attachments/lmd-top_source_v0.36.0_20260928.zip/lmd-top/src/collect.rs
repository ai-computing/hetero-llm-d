//! Snapshot 도메인 타입 + prometheus/kubectl 에서 수집하는 로직.
//! 각 소스는 독립적으로 실패해도 전체를 막지 않음(warnings 에 누적, 부재 필드는 None/빈값).

use crate::config::Config;
use crate::kube;
use crate::metrics;
use crate::prom::{self, Series};
use std::collections::BTreeMap;

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum AccelKind {
    Gpu,
    Rbln,
    Rngd,
    /// A device class declared at runtime (see `accel::packs`). The payload is the pack's slot
    /// in the registry, so `accel::by_kind` stays a bijection — a declared accelerator gets
    /// its own class rather than borrowing an existing one's colour and capabilities.
    Other(u16),
}
impl AccelKind {
    /// 벤더 계열 라벨(fallback). GPU 는 모델이 다양하므로 generic "GPU" — 실제 모델은 Accel.model.
    pub fn label(&self) -> &'static str {
        crate::accel::by_kind(*self).label
    }

    /// Stable sort rank: built-in classes keep their declaration order, declared ones follow.
    pub fn rank(&self) -> u16 {
        match self {
            AccelKind::Gpu => 0,
            AccelKind::Rbln => 1,
            AccelKind::Rngd => 2,
            AccelKind::Other(slot) => 3 + slot,
        }
    }
}

/// DCGM modelName("NVIDIA GB10", "NVIDIA A100-SXM4-40GB" 등) → 짧은 모델 토큰("GB10"/"A100").
/// 벤더 접두 제거 후 첫 토큰(공백/'-' 기준). 빈 값이면 빈 문자열.
fn gpu_model(raw: &str) -> String {
    let s = raw.trim();
    if s.is_empty() {
        return String::new();
    }
    let s = s
        .strip_prefix("NVIDIA ")
        .or_else(|| s.strip_prefix("Nvidia "))
        .unwrap_or(s);
    s.split([' ', '-']).next().unwrap_or(s).to_string()
}

#[derive(Clone)]
pub struct Accel {
    pub kind: AccelKind,
    pub model: String, // 실제 모델(예: GB10/A100/H100) — 메트릭 자동 감지, 없으면 ""
    pub id: String,    // rbln0 / npu0 / gpu0
    pub node: String,
    pub util: f64, // 0..100
    pub mem_used_gb: f64,
    pub mem_total_gb: f64,
    pub temp: f64,
    pub power: f64,
    pub busy_model: String, // exported_pod 등
    pub alive: bool,        // furiosa_npu_alive / RBLN HEALTH
    pub throttle: f64,      // furiosa throttling events (>0 = 스로틀링)
    pub unified_mem: bool,  // GB10/GH200 등 CPU·GPU 통합 메모리 → mem 은 호스트(노드) 풀
    pub mem_bw: f64,        // DCGM MEM_COPY_UTIL % (메모리 대역폭 압박), NaN=미지원
    pub clock_mhz: f64,     // DCGM SM_CLOCK MHz, NaN=미지원
    pub mem_temp: f64,      // DCGM MEMORY_TEMP °C, NaN=미지원
    pub energy_mj: f64,     // DCGM TOTAL_ENERGY_CONSUMPTION 누적(mJ), NaN=미지원
}
impl Accel {
    /// Is this device throttling? `None` when the hardware reports no throttling signal at
    /// all, which is not the same as "not throttling" — the field carries 0.0 either way, so
    /// callers that want to say "unknown" rather than "fine" need this distinction.
    pub fn throttling(&self) -> Option<bool> {
        crate::accel::by_kind(self.kind)
            .caps
            .throttle
            .then_some(self.throttle > 0.0)
    }

    /// Does this accelerator report cumulative energy (so session Wh is meaningful)?
    pub fn reports_energy(&self) -> bool {
        crate::accel::by_kind(self.kind).caps.energy
    }

    /// 표시용 계열/모델 라벨 — 감지된 모델이 있으면 그것, 없으면 벤더 라벨.
    pub fn disp(&self) -> &str {
        if self.model.is_empty() {
            self.kind.label()
        } else {
            self.model.as_str()
        }
    }
}

/// 통합 메모리(Grace 계열 superchip: GB10/GH200/GB200/GB300) 여부 — 별도 VRAM 없이 호스트와 공유.
fn is_unified(model: &str) -> bool {
    let m = model.to_uppercase();
    m.starts_with("GB10")
        || m.starts_with("GH200")
        || m.starts_with("GB200")
        || m.starts_with("GB300")
}

#[derive(Clone, Default)]
pub struct NodeInfo {
    pub name: String,
    pub load1: f64,
    pub mem_used_gb: f64,
    pub mem_total_gb: f64,
    pub cpu_pct: f64,
    pub disk_used_gb: f64, // 루트 파일시스템(mountpoint="/")
    pub disk_total_gb: f64,
    pub ready: bool,
    pub cordoned: bool,
    pub pressure: bool, // Memory/Disk/PID pressure 중 하나라도
    pub version: String,
    pub npu: String, // NPU 드라이버/SDK 요약(노드 라벨 기반, 예: "RNGD drv2026.3.0 · RBLN drv3.0.0"). 컴파일 가능 노드 판별용.
}

#[derive(Clone, Default)]
pub struct Pool {
    pub name: String,
    pub ready: f64,
    pub queue: f64,
    pub kv: f64,
    pub sat: f64,
    pub selector: String, // app=vllm-rbln-llama31-8b
    pub epp: String,      // endpointPickerRef (EPP service)
    pub ep_ready: i64,    // selector 매칭 파드 중 ready
    pub ep_total: i64,    // selector 매칭 파드 총수
}

#[derive(Clone)]
pub struct Route {
    pub path: String,
    pub backend: String,
    pub kind: String,  // Service | InferencePool
    pub route: String, // 소속 HTTPRoute 이름(편집 대상 지정용)
}

#[derive(Clone)]
pub struct Objective {
    pub name: String,
    pub priority: i64,
    pub pool: String,
}

#[derive(Clone)]
pub struct ModelRow {
    pub name: String,
    pub ready: i64,
    pub desired: i64,
    pub status: String,
    pub route: String,
    pub engine: String, // 추론 엔진(vLLM/SGLang/vLLM-RBLN/Ollama/Furiosa/custom)
    pub accel: String,  // 어떤 가속기/노드에서 도는지(파드 노드/가속기 추정)
    pub running: Option<f64>,
    pub waiting: Option<f64>,
    pub tps: Option<f64>,
    pub kv: Option<f64>,   // vllm:gpu_cache_usage_perc (0..1)
    pub ttft: Option<f64>, // TTFT p95 (s)
}

/// 공유 모델 스토어 인벤토리 항목(디스커버리 CronJob → model-inventory ConfigMap).
/// 배포 여부와 무관하게 "스토어에 존재하는" HF 원본/NPU 컴파일본.
#[derive(Clone, Default)]
pub struct StoredModel {
    pub repo: String,         // org/name (HF id) 또는 로컬 식별자
    pub family: String,       // 트리 그룹 키(정규화)
    pub revision: String,     // HF revision 또는 "-"
    pub format: String,       // hf | rbln | furiosa
    pub compiled_for: String, // 컴파일 타깃/옵션(예: RBLN-CA22-tp4-s8192) 또는 "-"
    pub size: String,         // du -sh 결과
    pub path: String,         // 스토어 내 상대 경로
    /// Toolchain that produced this build, as the scan read it out of the artifact itself
    /// (`optimum-rbln=0.10.2`, `furiosa-compiler=2026.3.0`), or `-` when unknown.
    ///
    /// This is the one fact that identifies *why* a build works when an identical-looking
    /// rebuild does not — see docs/RBLN-COMPILE-INCIDENT.md, where the answer was a version
    /// recorded inside a working artifact and nowhere else.
    pub built_with: String,
}

/// Shared store capacity, as measured inside the discovery scan.
///
/// A PVC's `status.capacity` reports the *requested* size, which on this cluster's SMB backend
/// is unrelated to what is actually free. Only a pod with the claim mounted can measure it, and
/// the discovery scan already is one — so it publishes `df` alongside the inventory.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct StoreCapacity {
    pub total_bytes: u64,
    pub used_bytes: u64,
    pub avail_bytes: u64,
}

impl StoreCapacity {
    /// Used share of the filesystem, 0-100. Uses used/(used+avail) rather than used/total:
    /// reserved blocks make those differ, and the second is what the operator can act on.
    pub fn used_pct(&self) -> f64 {
        let usable = self.used_bytes.saturating_add(self.avail_bytes);
        if usable == 0 {
            return 0.0;
        }
        self.used_bytes as f64 * 100.0 / usable as f64
    }
}

/// 컴파일 Job 진행 상태(Deploy 뷰 '진행 중 컴파일' 패널). `compile-*` Job 을 요약.
#[derive(Clone, Default)]
pub struct CompileJob {
    /// Namespace/name/UID identifies an execution, including retries under the same name.
    pub execution_id: String,
    pub name: String,               // Job 이름(compile-{모델}-{타깃})
    pub model: String,              // 사람이 읽는 모델(이름에서 추출)
    pub vendor: String,             // RBLN | RNGD | -
    pub target: String,             // 옵션 요약(tp/pp/seq 등, 이름의 타깃 부분)
    pub status: String,             // Running | Complete | Failed | Pending
    pub age_secs: u64,              // 시작(없으면 생성) 후 경과 초
    pub duration_secs: Option<u64>, // 완료된 경우 소요 초
    pub phase: String,              // 진행 힌트(파드 로그 마지막 줄 또는 상태)
    pub progress: Option<f32>,      // 로그에서 파싱한 진행률 0.0~1.0(없으면 indeterminate 바)
    /// Classified cause when the Job failed — replaces the old "see logs", and is what gets
    /// written to history before `ttlSecondsAfterFinished` removes the Job.
    pub failure: Option<crate::diagnose::Failure>,
    /// Compile options read off the Job's environment (tp, max-len, attn…).
    pub options: std::collections::BTreeMap<String, String>,
    /// HuggingFace source id from the Job's MODEL_ID env, for history keying.
    pub source: String,
    /// Toolchain versions the build ran against, reported by the recipe.
    pub toolchain: std::collections::BTreeMap<String, String>,
}

/// Store 뷰용 — 모델이 "어디에(경로/볼륨)" 저장되고 "어떤 옵션으로" 컴파일/서빙되는지.
/// deploy 컨테이너 spec(command/args/env/volumeMounts)에서 추출(휴리스틱).
#[derive(Clone, Default)]
pub struct ModelArtifact {
    pub model: String,  // deploy 이름(=변형 이름)
    pub family: String, // 트리 그룹 키(모델 계열, source/name 에서 정규화)
    pub engine: String, // 추론 엔진
    pub node: String,   // 저장/구동 노드(파드 스케줄 노드)
    pub image: String,  // 컨테이너 이미지
    pub source: String, // 모델 소스: HF id / --model 경로 / MODEL_ID
    pub mount: String,  // 저장 위치: "mountPath ← PVC/hostPath/emptyDir"
    /// Node-local directory backing the model volume, when it is a `hostPath`.
    ///
    /// Structured rather than scraped back out of `mount`, which is a display string. The
    /// artifacts actually serving on this cluster are hand-compiled hostPath directories, and
    /// reading anything out of one means running a pod on `node` with this path mounted.
    pub host_path: Option<String>,
    pub opts: Vec<(String, String)>, // 컴파일/서빙 옵션(TP·PP·max-len·batch·dtype·quant·NPU bucket 등)
}

#[derive(Clone)]
pub struct EventRow {
    pub typ: String, // Normal | Warning
    pub reason: String,
    pub object: String, // kind/name
    pub message: String,
    pub count: i64,
}

#[derive(Clone)]
pub struct PodRow {
    pub name: String,
    pub phase: String,
    pub ready: String,
    pub node: String,
    pub restarts: i64,
    pub age_secs: u64, // 생성 후 경과(초) — 배포 시작 시각 표시용. 0=미상.
}

#[derive(Clone)]
pub struct EppCfg {
    pub profile: String,
    pub scorers: Vec<(String, f64)>,
    pub picker: String,
}

/// 플랫폼 부트스트랩 전제조건 프로브 — 새 llm-d 환경 셋업 시 "무엇이 이미 있고 무엇이 없나".
/// Setup 뷰(Doctor)가 이걸 읽어 present/missing + 가이드된 조치를 렌더한다. 전부 read-only kubectl.
#[derive(Clone, Default)]
pub struct SetupProbe {
    pub probed: bool,      // kubectl 도달 가능 → 프로브 수행됨(false 면 클러스터 미연결)
    pub ns_exists: bool,   // 대상 namespace 존재
    pub crd_gateway: bool, // gateways.gateway.networking.k8s.io CRD
    pub crd_httproute: bool, // httproutes.gateway.networking.k8s.io CRD
    pub crd_infpool: bool, // inferencepools.inference.networking.k8s.io CRD (GIE GA)
    pub gatewayclasses: Vec<String>, // 사용 가능한 GatewayClass 이름들(Gateway 생성 시 선택)
    pub gateway: bool,     // llm-d-gateway (대상 ns)
    pub epp_role_sa: bool, // 공유 Role llmd-router-epp-sa (helm 생성)
    pub epp_role_non_sa: bool, // 공유 Role llmd-router-epp-non-sa
    pub secret_hf: bool,   // hf-token secret (gated 모델 가중치 다운로드용)
    pub pvc_model_store: Option<String>, // model-store PVC phase(Bound/Pending) 또는 None(없음)
}

#[derive(Clone, Default)]
pub struct Snapshot {
    pub ts: u64,
    pub nodes: Vec<NodeInfo>,
    pub accel: Vec<Accel>,
    pub pools: Vec<Pool>,
    pub models: Vec<ModelRow>,
    pub artifacts: Vec<ModelArtifact>, // Store 뷰: 모델 저장 위치 + 컴파일/서빙 옵션
    pub stored: Vec<StoredModel>, // 공유 스토어 인벤토리(model-inventory ConfigMap) — 배포 무관
    /// 공유 스토어 여유 용량(디스커버리 스캔이 df 로 실측). None=미관측(구버전 스캔 등).
    pub store_capacity: Option<StoreCapacity>,
    pub compiles: Vec<CompileJob>, // 진행/최근 컴파일 Job(compile-*) — Deploy 뷰 모니터 패널
    pub pods: Vec<PodRow>,
    pub events: Vec<EventRow>,
    pub routes: Vec<Route>,
    pub objectives: Vec<Objective>,
    pub decisions: Vec<(String, f64)>, // (pod, 라우팅 픽 횟수) — 트래픽이 EPP 경유 시
    pub pod_queues: Vec<(String, f64)>, // per-pod 큐 깊이(요청 분배)
    pub endpoint_scores: Vec<(String, f64)>, // per-pod EPP composite score(epp-score-observer 플러그인). 없으면 빈 값.
    pub perf: Perf,
    pub perf_rows: Vec<PerfRow>, // 모델(=하드웨어)별 성능

    pub autoscalers: Vec<Autoscale>,
    pub epp: Option<EppCfg>,
    pub epp_in_path: bool, // HTTPRoute backend 중 InferencePool 이 있는가(없으면 EPP 우회)
    pub prefix_idx: f64,   // inference_extension_prefix_indexer_size
    pub gw_addr: String,
    pub gw_ok: bool,
    pub inventory: Vec<(String, i64, i64)>, // (가속기 resource, allocatable total, 사용중 requests)
    pub node_alloc: std::collections::BTreeMap<String, std::collections::BTreeMap<String, i64>>, // node → resource → 할당(파드 requests)
    pub warnings: Vec<String>,
    pub prom_ok: bool, // Prometheus 도달 가능 여부(false 면 "가속기 없음"이 아니라 연결 문제)
    pub setup: SetupProbe, // 플랫폼 부트스트랩 전제조건(Setup 뷰)
    pub pvcs: Vec<String>, // 대상 ns 에 실존하는 PVC 이름들 — prefetch/compile 대상 검증에 사용(빈 벡터=미관측)
}

impl Snapshot {
    /// 서빙 중(ready>0)인 모델 수 — 진단·요약·헤더가 공유하는 파생 지표.
    pub fn serving_count(&self) -> usize {
        self.models.iter().filter(|m| m.ready > 0).count()
    }
}

/// EPP 정책 수립용 성능 지표(구간별 지연 percentile·토큰분포·처리량). 값 없으면 NaN.
/// 클러스터 전역 성능 요약(throughput 라인 + timeline 용). 상세는 per-model(perf_rows)/drill-down.
#[derive(Clone)]
pub struct Perf {
    pub req_rate: f64,
    pub err_rate: f64,
    pub tps: f64,
    pub prefix_hit: f64,
    pub ttft_p95: f64,
    pub e2e_p95: f64,
}
impl Default for Perf {
    fn default() -> Self {
        let n = f64::NAN;
        Perf {
            req_rate: n,
            err_rate: n,
            tps: n,
            prefix_hit: n,
            ttft_p95: n,
            e2e_p95: n,
        }
    }
}

/// 모델(=특정 하드웨어 배치)별 성능 행. 값 없으면 NaN.
#[derive(Clone)]
pub struct PerfRow {
    pub model: String,
    pub req: f64,
    pub tps: f64,
    pub ttft_p95: f64,
    pub tpot_p95: f64,
    pub e2e_p95: f64,
    pub in_tok_p95: f64,
    pub out_tok_p95: f64,
    pub queue_p95: f64,   // request_queue_time — 스케줄링 대기
    pub prefill_p95: f64, // request_prefill_time — prefill(P) 구간
    pub decode_p95: f64,  // request_decode_time — decode(D) 구간
    pub preempt: f64,     // num_preemptions rate — KV/메모리 스래싱
}
impl PerfRow {
    fn new(model: &str) -> Self {
        let n = f64::NAN;
        PerfRow {
            model: model.to_string(),
            req: n,
            tps: n,
            ttft_p95: n,
            tpot_p95: n,
            e2e_p95: n,
            in_tok_p95: n,
            out_tok_p95: n,
            queue_p95: n,
            prefill_p95: n,
            decode_p95: n,
            preempt: n,
        }
    }
}

#[derive(Clone)]
pub struct Autoscale {
    pub target: String, // scaleTargetRef (deployment)
    pub min: i64,
    pub max: i64,
    pub replicas: i64,
    pub ready: bool,
    pub active: bool,
    pub triggers: String,
}

/// 메모리 바이트 → GB. RBLN/Furiosa/node DRAM 모두 bytes 단위(실측 확인).
fn to_gb(v: f64) -> f64 {
    if v.is_nan() {
        0.0
    } else {
        v / 1.0e9
    }
}

fn short(s: &str) -> String {
    s.chars().take(28).collect()
}

/// Surface a failed kubectl collector as a warning. A missing CRD ("the server doesn't have a
/// resource type") is a normal cluster shape, not a fault, so it stays quiet — everything else
/// (RBAC denial, unreachable API server, missing kubectl) must be visible, because an empty view
/// and a permission error otherwise look identical (REG-08 / BUG-09).
fn kube_warn(label: &str, e: &anyhow::Error, warn: &mut Vec<String>) {
    let m = e.to_string();
    if m.contains("doesn't have a resource type")
        || m.contains("could not find the requested resource")
    {
        return;
    }
    let reason = m.lines().last().unwrap_or("unknown error").trim();
    warn.push(format!("kube[{}]: {}", label, reason));
}

/// prom::query 결과를 warn 으로 해소 — join!/query_all 로 병렬 조회한 뒤 사용.
fn resolve(
    r: Result<Vec<Series>, anyhow::Error>,
    promql: &str,
    warn: &mut Vec<String>,
) -> Vec<Series> {
    match r {
        Ok(v) => v,
        Err(e) => {
            warn.push(format!("prom[{}]: {}", short(promql), e));
            Vec::new()
        }
    }
}

/// 단일 스칼라 결과(첫 값) — 없으면 NaN. (join! 병렬용, warn 없음)
async fn qs1(prom_base: &str, promql: &str) -> f64 {
    prom::query(prom_base, promql)
        .await
        .ok()
        .and_then(|v| v.first().map(|s| s.value))
        .unwrap_or(f64::NAN)
}

/// Perf 드릴다운(선택 모델) 온디맨드 상세 — 구간별 p50/p95/p99 + E2E 지연 버킷 분포(히스토그램).
#[derive(Clone, Default)]
pub struct PerfDetail {
    pub model: String,
    pub e2e: [f64; 3], // p50/p95/p99 (s)
    pub ttft: [f64; 3],
    pub tpot: [f64; 3],
    pub buckets: Vec<(f64, f64)>, // (le 상한 s, 해당 구간 rate) — 누적차 분포
}

/// 선택 모델의 지연 분포를 프로메테우스에서 즉석 조회(Enter 시). vLLM/ds4-proxy 엔진 구분.
pub async fn perf_detail(prom: &str, model: &str) -> PerfDetail {
    // (E2E metric, TTFT metric, TPOT metric, selector)
    let (e2e_m, ttft_m, tpot_m, sel) = if model == "ds4-proxy" {
        (
            "ds4_proxy_request_duration_seconds",
            "ds4_proxy_ttft_seconds",
            "",
            String::new(),
        )
    } else {
        (
            "vllm:e2e_request_latency_seconds",
            "vllm:time_to_first_token_seconds",
            "vllm:request_time_per_output_token_seconds",
            format!("{{service=\"{}\"}}", model),
        )
    };
    let q = |base: &str, quant: f64| {
        format!(
            "histogram_quantile({}, sum by (le)(rate({}_bucket{}[5m])))",
            quant, base, sel
        )
    };
    let has_tpot = !tpot_m.is_empty();
    // 쿼리 문자열을 먼저 바인딩(참조가 join 전체에서 살아있도록).
    let (qe50, qe95, qe99) = (q(e2e_m, 0.5), q(e2e_m, 0.95), q(e2e_m, 0.99));
    let (qt50, qt95, qt99) = (q(ttft_m, 0.5), q(ttft_m, 0.95), q(ttft_m, 0.99));
    let (qp50, qp95, qp99) = (q(tpot_m, 0.5), q(tpot_m, 0.95), q(tpot_m, 0.99));
    let qbuckets = format!("sum by (le)(rate({}_bucket{}[5m]))", e2e_m, sel);
    let (e50, e95, e99, t50, t95, t99, p50, p95, p99, buckets) = tokio::join!(
        qs1(prom, &qe50),
        qs1(prom, &qe95),
        qs1(prom, &qe99),
        qs1(prom, &qt50),
        qs1(prom, &qt95),
        qs1(prom, &qt99),
        async {
            if has_tpot {
                qs1(prom, &qp50).await
            } else {
                f64::NAN
            }
        },
        async {
            if has_tpot {
                qs1(prom, &qp95).await
            } else {
                f64::NAN
            }
        },
        async {
            if has_tpot {
                qs1(prom, &qp99).await
            } else {
                f64::NAN
            }
        },
        prom::query(prom, &qbuckets),
    );
    // 누적 버킷 → 구간별 분포(le 오름차순, 인접 차분).
    let mut cum: Vec<(f64, f64)> = buckets
        .unwrap_or_default()
        .iter()
        .filter_map(|s| {
            let le = s.l("le");
            let up = if le == "+Inf" {
                f64::INFINITY
            } else {
                le.parse::<f64>().ok()?
            };
            Some((up, s.value))
        })
        .collect();
    cum.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap_or(std::cmp::Ordering::Equal));
    let mut dist = Vec::new();
    let mut prev = 0.0;
    for (le, c) in &cum {
        let cnt = (c - prev).max(0.0);
        dist.push((*le, cnt));
        prev = *c;
    }
    PerfDetail {
        model: model.to_string(),
        e2e: [e50, e95, e99],
        ttft: [t50, t95, t99],
        tpot: [p50, p95, p99],
        buckets: dist,
    }
}

/// vLLM 모델 메트릭 묶음 (model_name 키).
struct Vllm {
    run: BTreeMap<String, Series>,
    wait: BTreeMap<String, Series>,
    tps: BTreeMap<String, Series>,
    kv: BTreeMap<String, Series>,
    ttft: BTreeMap<String, Series>,
}

/// deploy 컨테이너 command/args/image 로 추론 엔진 추정.
/// pod spec 의 여러 컨테이너 중 모델 서버 컨테이너 선택(프록시/사이드카 제외).
/// llm-d/게이트웨이는 프록시+모델서버 사이드카 패턴이 흔해 [0] 이 프록시일 수 있음.
fn model_container(spec: &serde_json::Value) -> &serde_json::Value {
    let arr = match spec["containers"].as_array() {
        Some(a) if !a.is_empty() => a,
        _ => return &spec["containers"][0],
    };
    let is_sidecar = |c: &serde_json::Value| {
        let n = c["name"].as_str().unwrap_or("").to_lowercase();
        let img = c["image"].as_str().unwrap_or("").to_lowercase();
        [
            "proxy", "sidecar", "istio", "envoy", "-router", "gateway", "dcgm", "exporter",
            "vector", "fluent", "otel",
        ]
        .iter()
        .any(|k| n.contains(k) || img.contains(k))
    };
    let looks_server = |c: &serde_json::Value| {
        let mut t = String::new();
        for key in ["command", "args"] {
            if let Some(a) = c[key].as_array() {
                for x in a {
                    if let Some(s) = x.as_str() {
                        t.push_str(&s.to_lowercase());
                        t.push(' ');
                    }
                }
            }
        }
        let img = c["image"].as_str().unwrap_or("").to_lowercase();
        [
            "vllm",
            "sglang",
            "furiosa",
            "ollama",
            "--model",
            "optimum",
            "text-generation",
        ]
        .iter()
        .any(|k| t.contains(k) || img.contains(k))
    };
    if let Some(c) = arr.iter().find(|c| looks_server(c)) {
        return c;
    }
    if let Some(c) = arr.iter().find(|c| !is_sidecar(c)) {
        return c;
    }
    &arr[0]
}

fn detect_engine(d: &serde_json::Value, accel: &str) -> String {
    let c = model_container(&d["spec"]["template"]["spec"]);
    let mut t = String::new();
    for key in ["command", "args"] {
        if let Some(arr) = c[key].as_array() {
            for x in arr {
                if let Some(s) = x.as_str() {
                    t.push_str(s);
                    t.push(' ');
                }
            }
        }
    }
    let t = t.to_lowercase();
    let img = c["image"].as_str().unwrap_or("").to_lowercase();
    let rbln = accel.contains("RBLN") || t.contains("rbln");
    if t.contains("sglang") {
        "SGLang".into()
    } else if t.contains("vllm") {
        if rbln {
            "vLLM-RBLN".into()
        } else {
            "vLLM".into()
        }
    } else if t.contains("ollama") || img.contains("ollama") {
        "Ollama".into()
    } else if t.contains("furiosa") {
        "Furiosa-LLM".into()
    } else if rbln {
        "custom(RBLN)".into()
    } else {
        "custom".into()
    }
}

/// deploy 컨테이너 spec(command/args/env/volumeMounts)에서 모델 저장 위치 + 컴파일/서빙 옵션 추출.
/// Host directory backing a volume, if it is a `hostPath`.
fn volume_host_path<'a>(pod: &'a serde_json::Value, vol_name: &str) -> Option<&'a str> {
    pod["volumes"]
        .as_array()?
        .iter()
        .find(|v| v["name"].as_str() == Some(vol_name))?["hostPath"]["path"]
        .as_str()
}

/// Is this mount plainly a library/system directory rather than a model?
///
/// Judged on the *backing* path, not the mount point: the RBLN deployments here mount
/// `/usr/lib` at `/host-rbln-lib`, so the container-side path looks model-ish and the host side
/// does not. Python package directories under a home directory are libraries too.
fn is_system_mount(mount_path: &str, backing: Option<&str>) -> bool {
    const SYS_PREFIXES: [&str; 9] = [
        "/usr/", "/lib", "/bin", "/sbin", "/etc/", "/dev/", "/proc", "/sys/", "/run/",
    ];
    let sys = |p: &str| {
        SYS_PREFIXES.iter().any(|q| p.starts_with(q))
            || matches!(p, "/usr" | "/lib" | "/bin" | "/sbin" | "/dev")
            || p.contains("/site-packages")
            || p.contains("/dist-packages")
    };
    sys(mount_path) || backing.is_some_and(sys)
}

/// Choose the volumeMount that holds the model, by scoring rather than first-match.
///
/// First-match was wrong on this cluster: every RBLN deployment has a volume *named*
/// `host-rbln-lib`, the hint "rbln" matched its name, and it sorts before the volume actually
/// named `model` — so lmd-top reported the model as living in `/usr/lib` for eight of sixteen
/// deployments. Scoring with system mounts disqualified picks the model directory instead.
fn pick_model_mount<'a>(
    vms: &'a [serde_json::Value],
    pod: &serde_json::Value,
) -> Option<&'a serde_json::Value> {
    // Strong: names a model or its artifacts. Medium: a vendor build directory. Weak: a cache
    // that may or may not be the model's.
    const STRONG: [&str; 7] = [
        "model",
        "artifact",
        "ckpt",
        "checkpoint",
        "weight",
        "gguf",
        "safetensor",
    ];
    const MEDIUM: [&str; 4] = ["rbln", "furiosa", "fxb", "compiled"];
    const WEAK: [&str; 5] = ["hf", "cache", "data", "npu", "store"];

    let score = |m: &serde_json::Value| -> i32 {
        let mp = m["mountPath"].as_str().unwrap_or("").to_lowercase();
        let vn = m["name"].as_str().unwrap_or("");
        let backing = volume_host_path(pod, vn);
        if is_system_mount(&mp, backing) {
            return -1;
        }
        let hay = format!(
            "{} {} {}",
            mp,
            vn.to_lowercase(),
            backing.unwrap_or("").to_lowercase()
        );
        let hits = |set: &[&str]| set.iter().filter(|h| hay.contains(**h)).count() as i32;
        hits(&STRONG) * 3 + hits(&MEDIUM) * 2 + hits(&WEAK)
    };

    // Highest score wins. Ties keep document order, which preserves the old behaviour for the
    // cases that were already right -- max_by_key returns the *last* maximum, so the index is
    // reversed to make the first one win. If everything is disqualified we still fall back to
    // the first mount, so the field says something rather than nothing.
    vms.iter()
        .enumerate()
        .filter(|(_, m)| score(m) >= 0)
        .max_by_key(|(i, m)| (score(m), std::cmp::Reverse(*i)))
        .map(|(_, m)| m)
        .or_else(|| vms.first())
}

fn model_artifact(d: &serde_json::Value, name: &str, engine: &str) -> ModelArtifact {
    let pod = &d["spec"]["template"]["spec"];
    let c = model_container(pod);
    let image = c["image"].as_str().unwrap_or("").to_string();

    let mut toks: Vec<String> = Vec::new();
    for key in ["command", "args"] {
        if let Some(arr) = c[key].as_array() {
            for x in arr {
                if let Some(s) = x.as_str() {
                    toks.push(s.to_string());
                }
            }
        }
    }
    let mut env: Vec<(String, String)> = Vec::new();
    if let Some(arr) = c["env"].as_array() {
        for e in arr {
            if let (Some(n), Some(v)) = (e["name"].as_str(), e["value"].as_str()) {
                env.push((n.to_string(), v.to_string()));
            }
        }
    }
    // `--key value` / `--key=value` 값 추출.
    let arg_val = |flag: &str| -> Option<String> {
        for (i, t) in toks.iter().enumerate() {
            if let Some(rest) = t.strip_prefix(flag) {
                if let Some(v) = rest.strip_prefix('=') {
                    return Some(v.to_string());
                }
                if rest.is_empty() {
                    return toks.get(i + 1).cloned();
                }
            }
        }
        None
    };
    let env_val = |keys: &[&str]| -> Option<String> {
        env.iter()
            .find(|(n, _)| keys.iter().any(|k| n.eq_ignore_ascii_case(k)))
            .map(|(_, v)| v.clone())
    };

    // HF id(`org/model`) 또는 경로처럼 보이는 토큰만(셸 스크립트 인자 `sh -c "…"` 는 공백/개행 포함 → 제외).
    let looks_like_model = |t: &&String| -> bool {
        !t.starts_with('-')
            && t.contains('/')
            && !t
                .chars()
                .any(|c| c.is_whitespace() || matches!(c, ';' | '#' | '&' | '|' | '='))
    };
    let source = arg_val("--model")
        .or_else(|| arg_val("--model-path"))
        .or_else(|| {
            env_val(&[
                "MODEL_ID",
                "HF_MODEL_ID",
                "MODEL_PATH",
                "MODEL",
                "HF_MODEL",
                "SERVED_MODEL_NAME",
            ])
        })
        .or_else(|| toks.iter().find(looks_like_model).cloned())
        .unwrap_or_default();

    // 저장 위치: 어느 volumeMount 가 "모델"인지 점수로 고른다.
    let mut mount = String::new();
    let mut host_path: Option<String> = None;
    if let Some(vms) = c["volumeMounts"].as_array() {
        let pick = pick_model_mount(vms, pod);
        if let Some(m) = pick {
            let mp = m["mountPath"].as_str().unwrap_or("").to_string();
            let vn = m["name"].as_str().unwrap_or("");
            host_path = pod["volumes"]
                .as_array()
                .and_then(|vs| vs.iter().find(|v| v["name"].as_str() == Some(vn)))
                .and_then(|v| v["hostPath"]["path"].as_str())
                .map(|p| p.to_string());
            let backing = pod["volumes"]
                .as_array()
                .and_then(|vs| vs.iter().find(|v| v["name"].as_str() == Some(vn)))
                .map(|v| {
                    if let Some(pvc) = v["persistentVolumeClaim"]["claimName"].as_str() {
                        format!("PVC:{}", pvc)
                    } else if let Some(hp) = v["hostPath"]["path"].as_str() {
                        format!("host:{}", hp)
                    } else if v.get("emptyDir").is_some() {
                        "emptyDir".into()
                    } else if let Some(cm) = v["configMap"]["name"].as_str() {
                        format!("cm:{}", cm)
                    } else {
                        "vol".into()
                    }
                })
                .unwrap_or_default();
            mount = if backing.is_empty() {
                mp
            } else {
                format!("{} ← {}", mp, backing)
            };
        }
    }

    // 컴파일/서빙 옵션.
    let mut opts: Vec<(String, String)> = Vec::new();
    let mut push = |k: &str, v: Option<String>| {
        if let Some(v) = v {
            if !v.is_empty() {
                opts.push((k.into(), v));
            }
        }
    };
    // 병렬화(공통): TP/PP/DP.
    push(
        "tp",
        arg_val("--tensor-parallel-size")
            .or_else(|| arg_val("-tp"))
            .or_else(|| env_val(&["TENSOR_PARALLEL_SIZE", "RBLN_TENSOR_PARALLEL_SIZE"])),
    );
    push(
        "pp",
        arg_val("--pipeline-parallel-size").or_else(|| arg_val("-pp")),
    );
    push(
        "dp",
        arg_val("--data-parallel-size").or_else(|| arg_val("-dp")),
    );
    // 길이/배치(NPU 는 컴파일 시 고정되는 값 — RBLN max_seq_len / Furiosa bucket).
    push(
        "max-len",
        arg_val("--max-model-len")
            .or_else(|| arg_val("--max-seq-len"))
            .or_else(|| env_val(&["RBLN_MAX_SEQ_LEN", "MAX_SEQ_LEN"])),
    );
    push("max-seqs", arg_val("--max-num-seqs"));
    push(
        "batch",
        arg_val("--max-num-batched-tokens")
            .or_else(|| env_val(&["BATCH_SIZE", "MAX_BATCH_SIZE", "RBLN_BATCH_SIZE"])),
    );
    push(
        "bucket",
        arg_val("--bucket-config")
            .or_else(|| arg_val("--prefill-buckets"))
            .or_else(|| arg_val("--decode-buckets")),
    ); // Furiosa RNGD
       // 정밀도/양자화.
    push("dtype", arg_val("--dtype").or_else(|| env_val(&["DTYPE"])));
    push(
        "quant",
        arg_val("--quantization").or_else(|| env_val(&["QUANTIZATION", "RBLN_QUANTIZATION"])),
    );
    push("kv-dtype", arg_val("--kv-cache-dtype"));
    push("block", arg_val("--block-size"));
    // 디바이스/타깃 NPU.
    push("device", arg_val("--device"));
    push("devices", arg_val("--devices")); // Furiosa PE 지정
    push("npu", arg_val("--npu").or_else(|| env_val(&["RBLN_NPU"]))); // RBLN 타깃 칩(예: RBLN-CA22)
    push("gpu-mem", arg_val("--gpu-memory-utilization"));
    // NPU 특화 env / args (RBLN·Furiosa·compile).
    for (n, v) in &env {
        let nu = n.to_uppercase();
        if (nu.starts_with("RBLN_")
            || nu.starts_with("FURIOSA_")
            || nu.contains("COMPILE")
            || nu.contains("NPU"))
            && opts.len() < 14
            && !v.is_empty()
        {
            opts.push((n.clone(), v.clone()));
        }
    }
    for t in &toks {
        if (t.starts_with("--rbln") || t.starts_with("--furiosa") || t.starts_with("--compile"))
            && opts.len() < 14
        {
            let (k, v) = match t.split_once('=') {
                Some((a, b)) => (a.to_string(), b.to_string()),
                None => (t.clone(), "✓".into()),
            };
            opts.push((k.trim_start_matches("--").into(), v));
        }
    }

    let family = model_family(&source, name);
    ModelArtifact {
        model: name.to_string(),
        family,
        engine: engine.to_string(),
        node: String::new(),
        image,
        source,
        mount,
        host_path,
        opts,
    }
}

/// 변형(양자화/정밀도/HW/엔진) 태그를 벗겨 모델 "베이스" 이름만 남김.
fn strip_variant_tags(s: &str) -> String {
    let mut b = s.to_lowercase();
    for pre in ["vllm-", "sglang-", "ollama-", "furiosa-", "k-"] {
        if let Some(x) = b.strip_prefix(pre) {
            b = x.to_string();
        }
    }
    for suf in [
        "-instruct",
        "-chat",
        "-awq",
        "-gptq",
        "-fp8",
        "-bf16",
        "-fp16",
        "-int8",
        "-int4",
        "-w4a16",
        "-w8a8",
        "-nvfp4a16",
        "-nvfp4",
        "-mxfp4",
        "-rbln",
        "-gb10",
        "-npu",
        "-cpu",
        "-gpu",
        "-llm-d",
        "-modelservice",
        "-decode",
        "-prefill",
        "-proxy",
        "-server",
        "-n2",
        "-n3",
        "-v2",
        "-hf",
    ] {
        b = b.replace(suf, "");
    }
    b.trim_matches(|c| c == '-' || c == '_' || c == '.')
        .to_string()
}

/// 트리 그룹 키(모델 계열) — 표준 정체성. 우선순위: HF repo id(org/name) > 경로 leaf > deploy 이름.
/// 같은 모델의 여러 배포/컴파일본(다른 TP·양자화·노드)이 한 계열로 묶이도록 정규화.
pub(crate) fn model_family(source: &str, name: &str) -> String {
    // 1) HF id: "org/Name" — org 유지(중복 방지) + name 부분 변형태그 제거.
    if source.contains('/')
        && !source.starts_with('/')
        && !source.chars().any(|c| c.is_whitespace())
    {
        let mut it = source.rsplitn(2, '/');
        let leaf = it.next().unwrap_or(source);
        let org = it.next();
        let base = strip_variant_tags(leaf);
        let base = if base.is_empty() {
            leaf.to_lowercase()
        } else {
            base
        };
        return match org {
            Some(o) if !o.is_empty() => format!("{}/{}", o.to_lowercase(), base),
            _ => base,
        };
    }
    // 2) 로컬 경로: leaf 디렉터리 이름.
    if source.starts_with('/') {
        let leaf = source.rsplit('/').find(|s| !s.is_empty()).unwrap_or(source);
        let b = strip_variant_tags(leaf);
        if !b.is_empty() {
            return b;
        }
    }
    // 3) deploy 이름.
    let b = strip_variant_tags(name);
    if b.is_empty() {
        name.to_string()
    } else {
        b
    }
}

/// 모델 deploy 가 어느 가속기/노드에서 도는지 추정(가속기 busy_model 라벨이 파드명 ⊇ deploy명).
fn accel_for(accels: &[Accel], deploy: &str) -> String {
    let mut kind = "";
    let mut node = "";
    let mut n = 0;
    for a in accels {
        if !a.busy_model.is_empty() && a.busy_model.starts_with(deploy) {
            kind = a.disp(); // 감지된 모델(GB10 등), 없으면 벤더 라벨
            node = &a.node;
            n += 1;
        }
    }
    if n > 0 {
        format!("{}×{} {}", kind, n, node)
    } else {
        "–".to_string()
    }
}

/// uuid 등 key 기준으로 first-match value 맵 (Vec 소유 → 수명 단순화).
fn map_by(series: Vec<Series>, key: &str) -> BTreeMap<String, Series> {
    let mut m = BTreeMap::new();
    for s in series {
        let k = s.l(key).to_string();
        m.entry(k).or_insert(s);
    }
    m
}

/// Collect every device of one accelerator family, driven by its [`Pack`].
///
/// Replaces three near-identical per-vendor collectors. Each one queried its own metric names,
/// read its own label spelling, and normalised its own units — which is where the unit-guessing
/// bug lived (BUG-04) and where a fourth accelerator would have meant a fourth copy. The pack
/// declares metric, unit, aggregation, label spelling and capabilities; this walks them.
async fn collect_pack(prom: &str, pack: &'static crate::accel::Pack) -> Vec<Accel> {
    use crate::accel::{Agg, Field, Health};

    // One query per declared series, all in parallel. Aggregation is pushed into PromQL so a
    // per-core series (Furiosa) collapses the way the pack asks.
    let queries: Vec<String> = pack
        .series
        .iter()
        .map(|sp| {
            let by = std::iter::once(pack.labels.key)
                .chain([pack.labels.id, pack.labels.node])
                .chain(pack.labels.model)
                .chain(pack.labels.busy)
                .collect::<std::collections::BTreeSet<_>>()
                .into_iter()
                .collect::<Vec<_>>()
                .join(",");
            let f = match sp.agg {
                Agg::Max => "max",
                Agg::Avg => "avg",
                Agg::Sum => "sum",
            };
            format!("{} by ({}) ({})", f, by, sp.metric)
        })
        .collect();
    let refs: Vec<&str> = queries.iter().map(String::as_str).collect();
    let results = prom::query_all(prom, &refs).await;

    // The utilisation series enumerates the devices; the rest are joined onto it by key label.
    let util_idx = pack
        .series
        .iter()
        .position(|sp| sp.field == Field::Util)
        .expect("every pack declares a Util series");
    let mut by_field: BTreeMap<Field, BTreeMap<String, Series>> = BTreeMap::new();
    for (sp, r) in pack.series.iter().zip(results) {
        let rows = r.unwrap_or_default();
        by_field.insert(sp.field, map_by(rows, pack.labels.key));
    }
    let Some(util) = by_field.get(&Field::Util) else {
        return Vec::new();
    };

    // Read a field for one device, already normalised to the UI's unit.
    let read = |field: Field, key: &str| -> Option<f64> {
        let sp = pack.series_for(field)?;
        let v = by_field.get(&field)?.get(key)?.value;
        Some(sp.unit.normalise(v))
    };
    // Fields this accelerator does not report stay NaN — distinguishable from a zero reading.
    let read_or_nan = |field: Field, key: &str| read(field, key).unwrap_or(f64::NAN);

    let mut out: Vec<Accel> = Vec::new();
    for (key, sample) in util {
        let model = pack
            .labels
            .model
            .map(|l| gpu_model(sample.l(l)))
            .unwrap_or_default();
        let unified = pack.caps.unified_memory || is_unified(&model);
        let id = {
            let raw = sample.l(pack.labels.id);
            // DCGM's device label is a bare index; the others already carry a device name.
            if pack.kind == AccelKind::Gpu {
                format!("gpu{}", raw)
            } else {
                raw.to_string()
            }
        };
        let alive = match pack.caps.health {
            Some(Health::NonZeroIsAlive) => read(Field::Health, key).map(|v| v > 0.0),
            Some(Health::ZeroIsHealthy) => read(Field::Health, key).map(|v| v == 0.0),
            // No health series: a device that is being scraped is present.
            None => None,
        }
        .unwrap_or(true);
        out.push(Accel {
            kind: pack.kind,
            model,
            id,
            node: sample.l(pack.labels.node).to_string(),
            util: pack.series[util_idx].unit.normalise(sample.value),
            mem_used_gb: read(Field::MemUsed, key).unwrap_or(0.0),
            mem_total_gb: read(Field::MemTotal, key).unwrap_or(0.0),
            temp: read(Field::Temp, key).unwrap_or(0.0),
            power: read(Field::Power, key).unwrap_or(0.0),
            busy_model: pack
                .labels
                .busy
                .map(|l| sample.l(l).to_string())
                .unwrap_or_default(),
            alive,
            throttle: read(Field::Throttle, key).unwrap_or(0.0),
            unified_mem: unified,
            mem_bw: read_or_nan(Field::MemBandwidth, key),
            clock_mhz: read_or_nan(Field::ClockMhz, key),
            mem_temp: read_or_nan(Field::MemTemp, key),
            energy_mj: read_or_nan(Field::Energy, key),
        });
    }
    out
}

async fn collect_nodes(p: &str) -> Vec<NodeInfo> {
    let fs_size_q = format!("{}{{mountpoint=\"/\"}}", metrics::NODE_FS_SIZE);
    let fs_avail_q = format!("{}{{mountpoint=\"/\"}}", metrics::NODE_FS_AVAIL);
    let (load, mt, ma, cpu, ds, da, node_res) = tokio::join!(
        prom::query(p, metrics::NODE_LOAD1),
        prom::query(p, "node_memory_MemTotal_bytes"),
        prom::query(p, "node_memory_MemAvailable_bytes"),
        prom::query(
            p,
            "100 - (avg by (instance)(rate(node_cpu_seconds_total{mode=\"idle\"}[1m])) * 100)"
        ),
        prom::query(p, &fs_size_q),
        prom::query(p, &fs_avail_q),
        node_kube(),
    );
    let (node_ip, node_meta) = node_res;
    let load = load.unwrap_or_default();
    let n_mt = map_by(mt.unwrap_or_default(), "instance");
    let n_ma = map_by(ma.unwrap_or_default(), "instance");
    let n_cpu = map_by(cpu.unwrap_or_default(), "instance");
    let n_ds = map_by(ds.unwrap_or_default(), "instance");
    let n_da = map_by(da.unwrap_or_default(), "instance");
    let resolve = |inst: &str| -> String {
        let ip = inst.split(':').next().unwrap_or(inst);
        node_ip.get(ip).cloned().unwrap_or_else(|| ip.to_string())
    };
    let mut load_by: BTreeMap<String, f64> = BTreeMap::new();
    let mut inst_by: BTreeMap<String, String> = BTreeMap::new();
    for s in &load {
        let name = resolve(s.l("instance"));
        inst_by.insert(name.clone(), s.l("instance").to_string());
        load_by.insert(name, s.value);
    }
    let mut names: Vec<String> = node_meta.keys().cloned().collect();
    if names.is_empty() {
        names = load_by.keys().cloned().collect();
    }
    let mut nodes: Vec<NodeInfo> = Vec::new();
    for name in names {
        let inst = inst_by.get(&name).cloned().unwrap_or_default();
        let mt = n_mt.get(inst.as_str()).map(|x| x.value).unwrap_or(0.0);
        let ma = n_ma.get(inst.as_str()).map(|x| x.value).unwrap_or(0.0);
        let dsz = n_ds.get(inst.as_str()).map(|x| x.value).unwrap_or(0.0);
        let dav = n_da.get(inst.as_str()).map(|x| x.value).unwrap_or(0.0);
        let meta = node_meta.get(&name).cloned().unwrap_or_default();
        nodes.push(NodeInfo {
            load1: load_by.get(&name).copied().unwrap_or(f64::NAN),
            mem_used_gb: to_gb(mt - ma),
            mem_total_gb: to_gb(mt),
            cpu_pct: n_cpu
                .get(inst.as_str())
                .map(|x| x.value)
                .unwrap_or(f64::NAN),
            disk_used_gb: to_gb(dsz - dav),
            disk_total_gb: to_gb(dsz),
            ready: meta.0,
            cordoned: meta.1,
            pressure: meta.2,
            version: meta.3,
            name,
            npu: String::new(), // collect_node_npu 가 라벨에서 채움(full tier)
        });
    }
    nodes.sort_by(|a, b| a.name.cmp(&b.name));
    nodes
}

/// fast tier: 소스별 수집기 4개를 병렬 실행 후 합침. util/mem 반응성을 위해 collect()에서 분리.
pub async fn collect_fast(cfg: &Config) -> (Vec<Accel>, Vec<NodeInfo>) {
    let p = &cfg.prom;
    // Every registered accelerator plus the host metrics, all concurrently. Adding an
    // accelerator changes nothing here — it appears in `accel::PACKS`.
    let devices = async {
        let mut set = tokio::task::JoinSet::new();
        for pack in crate::accel::packs().iter().copied() {
            let prom = p.clone();
            set.spawn(async move { collect_pack(&prom, pack).await });
        }
        let mut all = Vec::new();
        while let Some(joined) = set.join_next().await {
            if let Ok(devs) = joined {
                all.extend(devs);
            }
        }
        all
    };
    let (mut accel, nodes) = tokio::join!(devices, collect_nodes(p));
    accel.sort_by(|a, b| (a.kind.rank(), &a.node, &a.id).cmp(&(b.kind.rank(), &b.node, &b.id)));
    // 통합 메모리(GB10 등): 별도 VRAM 없음 → 노드(호스트) 메모리 풀로 backfill.
    for a in accel
        .iter_mut()
        .filter(|a| a.unified_mem && a.mem_total_gb <= 0.0)
    {
        if let Some(n) = nodes.iter().find(|n| n.name == a.node) {
            a.mem_used_gb = n.mem_used_gb;
            a.mem_total_gb = n.mem_total_gb;
        }
    }
    (accel, nodes)
}

pub async fn collect(cfg: &Config) -> Snapshot {
    let mut snap = Snapshot::default();
    let mut warn = Vec::new();
    snap.ts = now_secs();

    // Prometheus 도달성 프로브 — 실패 시 빈 테이블을 "장비 없음"이 아니라 연결 문제로 구분.
    // 프로브는 2초·무재시도이며, 실패 시 서킷을 열어 이후 쿼리들이 네트워크를 건드리지 않게 한다.
    // (서킷 없이는 도달 불가 클러스터의 collect 가 92초 걸려 첫 화면까지 프리즈됐다 — BUG-01.)
    snap.prom_ok = prom::probe(&cfg.prom).await;
    if !snap.prom_ok {
        warn.push(format!(
            "Prometheus unreachable at {} — metric columns stay empty (check LMD_PROM)",
            cfg.prom
        ));
    }

    // 가속기 + 노드는 fast tier(collect_fast) 재사용 — 중복 제거
    let (accel, nodes) = collect_fast(cfg).await;
    snap.accel = accel;
    snap.nodes = nodes;
    collect_node_npu(&mut snap.nodes).await; // 노드 라벨에서 NPU 드라이버/SDK 요약 채움

    // ---------- EPP pools (독립 쿼리 — 병렬 배칭으로 순차 라운드트립 제거) ----------
    let dec_q = "sum by (pod_name) (inference_extension_scheduler_attempts_total)";
    let pidx_q = "max(inference_extension_prefix_indexer_size)";
    let (r_ready, r_q, r_kv, r_sat, r_dec, r_pidx, r_ppq, r_score) = tokio::join!(
        prom::query(&cfg.prom, metrics::POOL_READY),
        prom::query(&cfg.prom, metrics::POOL_QUEUE),
        prom::query(&cfg.prom, metrics::POOL_KV),
        prom::query(&cfg.prom, metrics::POOL_SAT),
        prom::query(&cfg.prom, dec_q),
        prom::query(&cfg.prom, pidx_q),
        prom::query(&cfg.prom, metrics::POOL_PER_POD_QUEUE),
        prom::query(&cfg.prom, metrics::EPP_ENDPOINT_SCORE),
    );
    let p_ready = resolve(r_ready, metrics::POOL_READY, &mut warn);
    let p_q = map_by(resolve(r_q, metrics::POOL_QUEUE, &mut warn), "name");
    let p_kv = map_by(resolve(r_kv, metrics::POOL_KV, &mut warn), "name");
    let p_sat = map_by(resolve(r_sat, metrics::POOL_SAT, &mut warn), "name");
    // 라우팅 결정 분배 (트래픽이 EPP 경유 시 채워짐)
    let dec = resolve(r_dec, dec_q, &mut warn);
    for s in &dec {
        let pod = s.l("pod_name");
        if !pod.is_empty() {
            snap.decisions.push((pod.to_string(), s.value));
        }
    }
    snap.decisions
        .sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
    let pidx = resolve(r_pidx, pidx_q, &mut warn);
    snap.prefix_idx = pidx.first().map(|s| s.value).unwrap_or(f64::NAN);

    // per-pod 큐 깊이(요청 분배)
    for s in &resolve(r_ppq, metrics::POOL_PER_POD_QUEUE, &mut warn) {
        let pod = s.l("model_server_pod");
        if !pod.is_empty() {
            snap.pod_queues.push((pod.to_string(), s.value));
        }
    }
    snap.pod_queues
        .sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));

    // per-pod EPP composite score (epp-score-observer 플러그인 배포 시 채워짐; 없으면 빈 값 → '–')
    for s in &resolve(r_score, metrics::EPP_ENDPOINT_SCORE, &mut warn) {
        let pod = s.l("pod");
        if !pod.is_empty() {
            snap.endpoint_scores.push((pod.to_string(), s.value));
        }
    }

    // Perf: 구간별 지연 percentile·토큰분포·처리량 (EPP 정책용). 전부 graceful(NaN).
    let pp = &cfg.prom;
    // vLLM 네이티브 + Furiosa-LLM(K-EXAONE) 을 클러스터 전역으로 합산(엔진 무관 서빙 건강).
    let (req_v, err_rate, tps_v, prefix_hit, ttft_v, e2e_p95, req_f, tps_f, ttft_f) = tokio::join!(
        qs1(pp, "sum(rate(vllm:request_success_total[1m]))"),
        qs1(pp, "sum(rate(vllm:request_success_total{finished_reason=\"abort\"}[1m]))"),
        qs1(pp, "sum(rate(vllm:generation_tokens_total[1m]))"),
        qs1(pp, "sum(rate(vllm:prefix_cache_hits_total[5m])) / sum(rate(vllm:prefix_cache_queries_total[5m]))"),
        qs1(pp, "histogram_quantile(0.95, sum by (le)(rate(vllm:time_to_first_token_seconds_bucket[1m])))"),
        qs1(pp, "histogram_quantile(0.95, sum by (le)(rate(vllm:e2e_request_latency_seconds_bucket[1m])))"),
        qs1(pp, "sum(rate(furiosa_llm_request_success_total[1m]))"),
        qs1(pp, "sum(rate(furiosa_llm_generation_tokens_total[1m]))"),
        qs1(pp, "histogram_quantile(0.95, sum by (le)(rate(furiosa_llm_time_to_first_token_seconds_bucket[1m])))"),
    );
    // throughput 는 가산(NaN=0 취급, 둘 다 NaN 이면 NaN); TTFT 는 존재하는 값 우선(엔진 혼합 p95 는 근사).
    let nadd = |a: f64, b: f64| {
        if a.is_nan() && b.is_nan() {
            f64::NAN
        } else {
            (if a.is_nan() { 0.0 } else { a }) + (if b.is_nan() { 0.0 } else { b })
        }
    };
    let nor = |a: f64, b: f64| if a.is_nan() { b } else { a };
    snap.perf = Perf {
        req_rate: nadd(req_v, req_f),
        err_rate,
        tps: nadd(tps_v, tps_f),
        prefix_hit,
        ttft_p95: nor(ttft_v, ttft_f),
        e2e_p95,
    };

    // per-model 성능 — service(=Deployment 이름) 기준 병합. Models 뷰와 동일 키.
    // 여기선 pm 만 채우고, 런칭된 모델 seed 는 collect_kube(모델 목록) 이후에 좌조인(아래).
    let mut pm: BTreeMap<String, PerfRow> = BTreeMap::new();
    // per-model 지연/토큰/처리량 — 17개 독립 쿼리를 병렬 배칭(순차 라운드트립 제거).
    // (promql, 필드 setter). setter 는 캡처 없는 클로저라 fn 포인터로 강제.
    type Set = fn(&mut PerfRow, f64);
    let specs: &[(&str, Set)] = &[
        ("sum by (service)(rate(vllm:request_success_total[1m]))", |r, v| r.req = v),
        ("sum by (service)(rate(vllm:generation_tokens_total[1m]))", |r, v| r.tps = v),
        ("histogram_quantile(0.95, sum by (service,le)(rate(vllm:time_to_first_token_seconds_bucket[1m])))", |r, v| r.ttft_p95 = v),
        ("histogram_quantile(0.95, sum by (service,le)(rate(vllm:request_time_per_output_token_seconds_bucket[1m])))", |r, v| r.tpot_p95 = v),
        ("histogram_quantile(0.95, sum by (service,le)(rate(vllm:e2e_request_latency_seconds_bucket[1m])))", |r, v| r.e2e_p95 = v),
        ("histogram_quantile(0.95, sum by (service,le)(rate(vllm:request_prompt_tokens_bucket[1m])))", |r, v| r.in_tok_p95 = v),
        ("histogram_quantile(0.95, sum by (service,le)(rate(vllm:request_generation_tokens_bucket[1m])))", |r, v| r.out_tok_p95 = v),
        ("histogram_quantile(0.95, sum by (service,le)(rate(vllm:request_queue_time_seconds_bucket[1m])))", |r, v| r.queue_p95 = v),
        ("histogram_quantile(0.95, sum by (service,le)(rate(vllm:request_prefill_time_seconds_bucket[1m])))", |r, v| r.prefill_p95 = v),
        ("histogram_quantile(0.95, sum by (service,le)(rate(vllm:request_decode_time_seconds_bucket[1m])))", |r, v| r.decode_p95 = v),
        ("sum by (service)(rate(vllm:num_preemptions_total[1m]))", |r, v| r.preempt = v),
        // Furiosa-LLM (K-EXAONE 등): furiosa_llm_* 로 노출, 같은 service 조인키. TPOT≈inter-token-latency.
        ("sum by (service)(rate(furiosa_llm_request_success_total[1m]))", |r, v| r.req = v),
        ("sum by (service)(rate(furiosa_llm_generation_tokens_total[1m]))", |r, v| r.tps = v),
        ("histogram_quantile(0.95, sum by (service,le)(rate(furiosa_llm_time_to_first_token_seconds_bucket[1m])))", |r, v| r.ttft_p95 = v),
        ("histogram_quantile(0.95, sum by (service,le)(rate(furiosa_llm_inter_token_latency_seconds_bucket[1m])))", |r, v| r.tpot_p95 = v),
        ("histogram_quantile(0.95, sum by (service,le)(rate(furiosa_llm_request_prompt_tokens_bucket[1m])))", |r, v| r.in_tok_p95 = v),
        ("histogram_quantile(0.95, sum by (service,le)(rate(furiosa_llm_request_generation_tokens_bucket[1m])))", |r, v| r.out_tok_p95 = v),
    ];
    let qs: Vec<&str> = specs.iter().map(|(q, _)| *q).collect();
    let results = prom::query_all(&cfg.prom, &qs).await;
    for ((promql, set), r) in specs.iter().zip(results) {
        for s in &resolve(r, promql, &mut warn) {
            let m = s.l("service");
            if !m.is_empty() {
                set(
                    pm.entry(m.to_string()).or_insert_with(|| PerfRow::new(m)),
                    s.value,
                );
            }
        }
    }

    for s in &p_ready {
        let name = s.l("name");
        snap.pools.push(Pool {
            name: name.to_string(),
            ready: s.value,
            queue: p_q.get(name).map(|x| x.value).unwrap_or(f64::NAN),
            kv: p_kv.get(name).map(|x| x.value).unwrap_or(f64::NAN),
            sat: p_sat.get(name).map(|x| x.value).unwrap_or(f64::NAN),
            ..Default::default()
        });
    }

    // vLLM model metrics (모델 서버에 vLLM ServiceMonitor + 트래픽 있을 때 채워짐)
    // vLLM 네이티브와 Furiosa-LLM 을 같은 service 키로 병합(한 service 는 둘 중 하나만 노출 → 충돌 없음).
    // 10개 쿼리는 반드시 병렬(query_all) — 직렬 .await 였을 때 Prometheus 장애 시 이 블록만
    // 120초 규모로 늘어나 collect 전체를 마비시켰다(BUG-01).
    let vllm_qs: [&str; 10] = [
        "sum by (service) (vllm:num_requests_running)",
        "sum by (service) (vllm:num_requests_waiting)",
        "sum by (service) (rate(vllm:generation_tokens_total[1m]))",
        "max by (service) (vllm:kv_cache_usage_perc)",
        "histogram_quantile(0.95, sum by (service,le) (rate(vllm:time_to_first_token_seconds_bucket[1m])))",
        "sum by (service) (furiosa_llm_num_requests_running)",
        "sum by (service) (furiosa_llm_num_requests_waiting)",
        "sum by (service) (rate(furiosa_llm_generation_tokens_total[1m]))",
        "max by (service) (furiosa_llm_kv_cache_usage_percent)",
        "histogram_quantile(0.95, sum by (service,le) (rate(furiosa_llm_time_to_first_token_seconds_bucket[1m])))",
    ];
    let mut vres = prom::query_all(&cfg.prom, &vllm_qs).await.into_iter();
    let mut next = |warn: &mut Vec<String>, i: usize| {
        map_by(
            resolve(
                vres.next().unwrap_or_else(|| Ok(Vec::new())),
                vllm_qs[i],
                warn,
            ),
            "service",
        )
    };
    let mut vllm = Vllm {
        // service 라벨 = Deployment 이름(예: gemma4-rbln) → deploy 와 정확히 join.
        run: next(&mut warn, 0),
        wait: next(&mut warn, 1),
        tps: next(&mut warn, 2),
        kv: next(&mut warn, 3),
        ttft: next(&mut warn, 4),
    };
    vllm.run.extend(next(&mut warn, 5));
    vllm.wait.extend(next(&mut warn, 6));
    vllm.tps.extend(next(&mut warn, 7));
    vllm.kv.extend(next(&mut warn, 8));
    vllm.ttft.extend(next(&mut warn, 9));

    // ---------- kube: deployments / pods / routes / gateway / epp ----------
    collect_kube(cfg, &mut snap, &vllm, &mut warn).await;

    // per-model perf: 런칭된 모든 모델(snap.models)을 seed 로 → 트래픽 없어도 표(–)에 표시.
    // 배포명↔service 는 Models 뷰와 동일한 match_model 로 해석, pm(메트릭)을 좌조인.
    {
        let mut rows: Vec<PerfRow> = Vec::new();
        for m in &snap.models {
            let key = match_model(&m.name, &vllm.run);
            let mut row = key
                .and_then(|k| pm.remove(&k))
                .unwrap_or_else(|| PerfRow::new(&m.name));
            row.model = m.name.clone(); // 표시명을 배포명으로 통일(Models 와 일관)
            rows.push(row);
        }
        rows.extend(pm.into_values()); // 모델 목록엔 없지만 메트릭만 있는 잔여
        snap.perf_rows = rows;
    }

    // 커스텀 엔진 어댑터: ds4-inject-proxy 는 vLLM 이 아니라 `ds4_proxy_*` 로 노출 →
    // vllm:* 쿼리로는 안 잡힘. 프록시가 백엔드 라벨 없이 집계하므로 집계 perf 행 1개로 반영.
    // (저트래픽이라 5m 윈도로 안정화. 일반화는 로드맵의 선언적 collector.)
    {
        let pp = &cfg.prom;
        let (req, tok, ttft, e2e) = tokio::join!(
            qs1(pp, "sum(rate(ds4_proxy_requests_total[5m]))"),
            qs1(pp, "sum(rate(ds4_proxy_output_tokens_total[5m]))"),
            qs1(pp, "histogram_quantile(0.95, sum by (le)(rate(ds4_proxy_ttft_seconds_bucket[5m])))"),
            qs1(pp, "histogram_quantile(0.95, sum by (le)(rate(ds4_proxy_request_duration_seconds_bucket[5m])))"),
        );
        if !req.is_nan() || !ttft.is_nan() || !e2e.is_nan() {
            let mut r = PerfRow::new("ds4-proxy");
            r.req = req;
            r.tps = tok;
            r.ttft_p95 = ttft;
            r.e2e_p95 = e2e;
            snap.perf_rows.push(r);
        }
    }

    // ---------- 가속기 재고(런처 솔버용) ----------
    collect_inventory(&mut snap.inventory, &mut snap.node_alloc, &mut warn).await;

    // ---------- 플랫폼 부트스트랩 전제조건(Setup 뷰) ----------
    snap.setup = collect_setup(&cfg.ns).await;
    // BUG-08: `kubectl get deploy -n <missing-ns>` returns success + an empty list, so no collector
    // can tell "nothing deployed" from "wrong namespace". The Setup probe already knows — say so,
    // rather than leaving the user with silently empty views (ENV-03).
    if snap.setup.probed && !snap.setup.ns_exists {
        warn.push(format!(
            "namespace '{}' does not exist — every view stays empty (check LMD_NS)",
            cfg.ns
        ));
    }

    // ---------- 대상 ns 실존 PVC 목록(prefetch/compile 대상 검증용) ----------
    // 없는 PVC 로 Job 을 만들면 pod 가 영구 Pending(FailedScheduling)이 되므로, 폼이 실존 PVC 만 제시하고
    // submit 이 검증하도록 이름을 수집. 미도달/비어있으면 빈 벡터(검증 skip → 오탐 방지).
    if let Some(list) = kube::get_jsonpath(
        &["get", "pvc", "-n", &cfg.ns],
        "{range .items[*]}{.metadata.name}{\"\\n\"}{end}",
    )
    .await
    {
        snap.pvcs = list.split_whitespace().map(|s| s.to_string()).collect();
    }

    // History: serving observations feed the compile-option advisor.
    record_serving(&snap);

    snap.warnings = warn;
    snap
}

/// 플랫폼 전제조건 프로브 — read-only kubectl 몇 번으로 CRD/Gateway/Role/PVC/Secret 존재 확인.
/// kubectl 미도달이면 probed=false 로 반환(Setup 뷰가 "클러스터 미연결" 표시).
async fn collect_setup(ns: &str) -> SetupProbe {
    let mut p = SetupProbe::default();
    let ns_ref = format!("namespace/{}", ns);
    // kubectl 도달성 겸 namespace 존재 확인 — None(에러)이면 클러스터 미연결로 조기 반환.
    match kube::get_exists(&["get", &ns_ref]).await {
        Some(exists) => {
            p.probed = true;
            p.ns_exists = exists;
        }
        None => return p,
    }
    // CRDs (get_exists: kind/이름 없으면 Some(false), kubectl 자체 에러면 None→false)
    p.crd_gateway = kube::get_exists(&["get", "crd", "gateways.gateway.networking.k8s.io"])
        .await
        .unwrap_or(false);
    p.crd_httproute = kube::get_exists(&["get", "crd", "httproutes.gateway.networking.k8s.io"])
        .await
        .unwrap_or(false);
    p.crd_infpool = kube::get_exists(&["get", "crd", "inferencepools.inference.networking.k8s.io"])
        .await
        .unwrap_or(false);
    // 사용 가능한 GatewayClass 이름(Gateway 생성 시 gatewayClassName 후보)
    if p.crd_gateway {
        if let Some(s) =
            kube::get_jsonpath(&["get", "gatewayclass"], "{.items[*].metadata.name}").await
        {
            p.gatewayclasses = s.split_whitespace().map(|x| x.to_string()).collect();
        }
    }
    // 네임스페이스 스코프 오브젝트(CRD 없으면 get 자체가 실패 → false 로 안전 처리)
    if p.crd_gateway {
        p.gateway = kube::get_exists(&["get", "gateway", "llm-d-gateway", "-n", ns])
            .await
            .unwrap_or(false);
    }
    p.epp_role_sa = kube::get_exists(&["get", "role", "llmd-router-epp-sa", "-n", ns])
        .await
        .unwrap_or(false);
    p.epp_role_non_sa = kube::get_exists(&["get", "role", "llmd-router-epp-non-sa", "-n", ns])
        .await
        .unwrap_or(false);
    p.secret_hf = kube::get_exists(&["get", "secret", "hf-token", "-n", ns])
        .await
        .unwrap_or(false);
    p.pvc_model_store =
        kube::get_jsonpath(&["get", "pvc", "model-store", "-n", ns], "{.status.phase}")
            .await
            .filter(|s| !s.is_empty());
    p
}

const ACCEL_RESOURCES: [&str; 3] = ["nvidia.com/gpu", "rebellions.ai/ATOM", "furiosa.ai/rngd"];

/// 노드 allocatable 합계 − 파드 requests 합계 = 여유. (가속기 resource별)
async fn collect_inventory(
    inv: &mut Vec<(String, i64, i64)>,
    node_alloc: &mut BTreeMap<String, BTreeMap<String, i64>>,
    warn: &mut Vec<String>,
) {
    let mut total: BTreeMap<String, i64> = BTreeMap::new();
    let mut used: BTreeMap<String, i64> = BTreeMap::new();
    for r in ACCEL_RESOURCES {
        total.insert(r.to_string(), 0);
        used.insert(r.to_string(), 0);
    }
    // 노드 allocatable
    match kube::get_json(&["get", "nodes", "-o", "json"]).await {
        Ok(v) => {
            if let Some(items) = v["items"].as_array() {
                for n in items {
                    if let Some(a) = n["status"]["allocatable"].as_object() {
                        for r in ACCEL_RESOURCES {
                            if let Some(q) = a
                                .get(r)
                                .and_then(|x| x.as_str())
                                .and_then(|s| s.parse::<i64>().ok())
                            {
                                *total.get_mut(r).unwrap() += q;
                            }
                        }
                    }
                }
            }
        }
        Err(e) => warn.push(format!("inv nodes: {}", e)),
    }
    // 파드 requests (비종료 파드, 전 네임스페이스)
    if let Ok(v) = kube::get_json(&["get", "pods", "-A", "-o", "json"]).await {
        if let Some(items) = v["items"].as_array() {
            for p in items {
                let phase = p["status"]["phase"].as_str().unwrap_or("");
                if phase == "Succeeded" || phase == "Failed" {
                    continue;
                }
                let node = p["spec"]["nodeName"].as_str().unwrap_or("").to_string();
                if let Some(cs) = p["spec"]["containers"].as_array() {
                    for c in cs {
                        if let Some(req) = c["resources"]["requests"].as_object() {
                            for r in ACCEL_RESOURCES {
                                if let Some(q) = req
                                    .get(r)
                                    .and_then(|x| x.as_str())
                                    .and_then(|s| s.parse::<i64>().ok())
                                {
                                    *used.get_mut(r).unwrap() += q;
                                    if !node.is_empty() {
                                        *node_alloc
                                            .entry(node.clone())
                                            .or_default()
                                            .entry(r.to_string())
                                            .or_insert(0) += q;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    for r in ACCEL_RESOURCES {
        inv.push((r.to_string(), total[r], used[r]));
    }
}

type NodeMeta = (bool, bool, bool, String); // (ready, cordoned, pressure, version)

async fn node_kube() -> (BTreeMap<String, String>, BTreeMap<String, NodeMeta>) {
    let mut ip = BTreeMap::new();
    let mut meta = BTreeMap::new();
    if let Ok(v) = kube::get_json(&["get", "nodes", "-o", "json"]).await {
        if let Some(items) = v["items"].as_array() {
            for it in items {
                let name = it["metadata"]["name"].as_str().unwrap_or("").to_string();
                if let Some(addrs) = it["status"]["addresses"].as_array() {
                    for a in addrs {
                        if a["type"] == "InternalIP" {
                            if let Some(x) = a["address"].as_str() {
                                ip.insert(x.to_string(), name.clone());
                            }
                        }
                    }
                }
                let ver = it["status"]["nodeInfo"]["kubeletVersion"]
                    .as_str()
                    .unwrap_or("")
                    .to_string();
                let cordoned = it["spec"]["unschedulable"].as_bool().unwrap_or(false);
                let (mut ready, mut pressure) = (false, false);
                if let Some(cs) = it["status"]["conditions"].as_array() {
                    for c in cs {
                        let t = c["type"].as_str().unwrap_or("");
                        let st = c["status"] == "True";
                        match t {
                            "Ready" => ready = st,
                            "MemoryPressure" | "DiskPressure" | "PIDPressure" if st => {
                                pressure = true
                            }
                            _ => {}
                        }
                    }
                }
                meta.insert(name, (ready, cordoned, pressure, ver));
            }
        }
    }
    (ip, meta)
}

async fn collect_kube(cfg: &Config, snap: &mut Snapshot, vllm: &Vllm, warn: &mut Vec<String>) {
    // routes: path -> backend (+ kind: Service|InferencePool)
    let r = kube::get_json(&["get", "httproute", "-n", &cfg.ns, "-o", "json"]).await;
    if let Err(e) = &r {
        kube_warn("httproute", e, warn);
    }
    if let Ok(v) = r {
        if let Some(items) = v["items"].as_array() {
            for r in items {
                let route_name = r["metadata"]["name"].as_str().unwrap_or("").to_string();
                if let Some(rules) = r["spec"]["rules"].as_array() {
                    for rule in rules {
                        let backend = rule["backendRefs"][0]["name"]
                            .as_str()
                            .unwrap_or("")
                            .to_string();
                        let kind = rule["backendRefs"][0]["kind"]
                            .as_str()
                            .unwrap_or("Service")
                            .to_string();
                        if kind == "InferencePool" {
                            snap.epp_in_path = true;
                        }
                        if let Some(matches) = rule["matches"].as_array() {
                            for m in matches {
                                if let Some(p) = m["path"]["value"].as_str() {
                                    snap.routes.push(Route {
                                        path: p.to_string(),
                                        backend: backend.clone(),
                                        kind: kind.clone(),
                                        route: route_name.clone(),
                                    });
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    let route_for = |backend: &str| -> String {
        snap.routes
            .iter()
            .filter(|r| r.backend == backend)
            .map(|r| r.path.clone())
            .collect::<Vec<_>>()
            .join(",")
    };

    // deployments → models
    match kube::get_json(&["get", "deploy", "-n", &cfg.ns, "-o", "json"]).await {
        Ok(v) => {
            if let Some(items) = v["items"].as_array() {
                for d in items {
                    let name = d["metadata"]["name"].as_str().unwrap_or("").to_string();
                    if name.contains("epp") || name.contains("router") {
                        continue; // 라우터는 모델 아님
                    }
                    let desired = d["spec"]["replicas"].as_i64().unwrap_or(0);
                    let ready = d["status"]["readyReplicas"].as_i64().unwrap_or(0);
                    let status = if desired == 0 {
                        "○ Scaled-0".to_string()
                    } else if ready >= desired {
                        "● Running".to_string()
                    } else {
                        "◐ Pending".to_string()
                    };
                    // vllm 메트릭 fuzzy 매칭 (model_name ⊃/⊂ deploy 토큰)
                    let mn = match_model(name.as_str(), &vllm.run);
                    let accel = accel_for(&snap.accel, &name);
                    let engine = detect_engine(d, &accel);
                    snap.artifacts.push(model_artifact(d, &name, &engine));
                    snap.models.push(ModelRow {
                        route: route_for(&name),
                        engine,
                        accel,
                        running: mn.as_ref().and_then(|k| vllm.run.get(k)).map(|x| x.value),
                        waiting: mn.as_ref().and_then(|k| vllm.wait.get(k)).map(|x| x.value),
                        tps: mn.as_ref().and_then(|k| vllm.tps.get(k)).map(|x| x.value),
                        kv: mn.as_ref().and_then(|k| vllm.kv.get(k)).map(|x| x.value),
                        ttft: mn.as_ref().and_then(|k| vllm.ttft.get(k)).map(|x| x.value),
                        name,
                        ready,
                        desired,
                        status,
                    });
                }
            }
        }
        Err(e) => warn.push(format!("kube deploy: {}", e)),
    }
    snap.models.sort_by(|a, b| a.name.cmp(&b.name));

    // pods
    match kube::get_json(&["get", "pods", "-n", &cfg.ns, "-o", "json"]).await {
        Ok(v) => {
            if let Some(items) = v["items"].as_array() {
                for p in items {
                    let name = p["metadata"]["name"].as_str().unwrap_or("").to_string();
                    let phase = p["status"]["phase"].as_str().unwrap_or("?").to_string();
                    let node = p["spec"]["nodeName"].as_str().unwrap_or("-").to_string();
                    let (mut rc, mut total, mut readyc, mut restarts) = (0, 0, 0, 0i64);
                    if let Some(cs) = p["status"]["containerStatuses"].as_array() {
                        total = cs.len();
                        for c in cs {
                            if c["ready"].as_bool().unwrap_or(false) {
                                readyc += 1;
                            }
                            restarts += c["restartCount"].as_i64().unwrap_or(0);
                            rc += 1;
                        }
                    }
                    let _ = rc;
                    let age_secs = p["metadata"]["creationTimestamp"]
                        .as_str()
                        .and_then(parse_k8s_ts)
                        .map(|s| now_secs().saturating_sub(s))
                        .unwrap_or(0);
                    snap.pods.push(PodRow {
                        name,
                        phase,
                        ready: format!("{}/{}", readyc, total),
                        node,
                        restarts,
                        age_secs,
                    });
                }
            }
        }
        Err(e) => warn.push(format!("kube pods: {}", e)),
    }
    snap.pods.sort_by(|a, b| a.name.cmp(&b.name));

    collect_events(cfg, snap).await;
    collect_gateway(cfg, snap, warn).await;

    // EPP config (ConfigMap)
    if let Ok(v) =
        kube::get_json(&["get", "cm", "llmd-router-epp", "-n", &cfg.ns, "-o", "json"]).await
    {
        if let Some(text) = kube::cm_data(&v, "default-plugins.yaml") {
            snap.epp = parse_epp(text);
        }
    }

    // InferencePool 스펙(selector / EPP / endpoints) → prom Pool 과 병합
    let r = kube::get_json(&["get", "inferencepool", "-n", &cfg.ns, "-o", "json"]).await;
    if let Err(e) = &r {
        kube_warn("inferencepool", e, warn);
    }
    if let Ok(v) = r {
        if let Some(items) = v["items"].as_array() {
            for ip in items {
                let name = ip["metadata"]["name"].as_str().unwrap_or("").to_string();
                let epp = ip["spec"]["endpointPickerRef"]["name"]
                    .as_str()
                    .unwrap_or("")
                    .to_string();
                let mut sel = Vec::new();
                if let Some(ml) = ip["spec"]["selector"]["matchLabels"].as_object() {
                    for (k, val) in ml {
                        if let Some(s) = val.as_str() {
                            sel.push(format!("{}={}", k, s));
                        }
                    }
                }
                let selector = sel.join(",");
                let (mut ep_total, mut ep_ready) = (0i64, 0i64);
                if !selector.is_empty() {
                    if let Ok(pj) = kube::get_json(&[
                        "get", "pods", "-n", &cfg.ns, "-l", &selector, "-o", "json",
                    ])
                    .await
                    {
                        if let Some(ps) = pj["items"].as_array() {
                            ep_total = ps.len() as i64;
                            for p in ps {
                                let ready = p["status"]["containerStatuses"]
                                    .as_array()
                                    .map(|cs| {
                                        !cs.is_empty()
                                            && cs
                                                .iter()
                                                .all(|c| c["ready"].as_bool().unwrap_or(false))
                                    })
                                    .unwrap_or(false);
                                if ready {
                                    ep_ready += 1;
                                }
                            }
                        }
                    }
                }
                if let Some(pool) = snap.pools.iter_mut().find(|p| p.name == name) {
                    pool.selector = selector;
                    pool.epp = epp;
                    pool.ep_total = ep_total;
                    pool.ep_ready = ep_ready;
                } else {
                    snap.pools.push(Pool {
                        name,
                        selector,
                        epp,
                        ep_total,
                        ep_ready,
                        ready: f64::NAN,
                        queue: f64::NAN,
                        kv: f64::NAN,
                        sat: f64::NAN,
                    });
                }
            }
        }
    }

    // InferenceObjective (SLO priority)
    let r = kube::get_json(&["get", "inferenceobjective", "-n", &cfg.ns, "-o", "json"]).await;
    if let Err(e) = &r {
        kube_warn("inferenceobjective", e, warn);
    }
    if let Ok(v) = r {
        if let Some(items) = v["items"].as_array() {
            for o in items {
                snap.objectives.push(Objective {
                    name: o["metadata"]["name"].as_str().unwrap_or("").to_string(),
                    priority: o["spec"]["priority"].as_i64().unwrap_or(0),
                    pool: o["spec"]["poolRef"]["name"]
                        .as_str()
                        .unwrap_or("")
                        .to_string(),
                });
            }
        }
    }
    snap.objectives
        .sort_by_key(|o| std::cmp::Reverse(o.priority));

    // 오토스케일링 (KEDA ScaledObject + 상태)
    let r = kube::get_json(&["get", "scaledobject", "-n", &cfg.ns, "-o", "json"]).await;
    if let Err(e) = &r {
        kube_warn("scaledobject", e, warn);
    }
    if let Ok(v) = r {
        if let Some(items) = v["items"].as_array() {
            for so in items {
                let target = so["spec"]["scaleTargetRef"]["name"]
                    .as_str()
                    .unwrap_or("")
                    .to_string();
                let min = so["spec"]["minReplicaCount"].as_i64().unwrap_or(0);
                let max = so["spec"]["maxReplicaCount"].as_i64().unwrap_or(0);
                let conds = so["status"]["conditions"].as_array();
                let cond = |t: &str| {
                    conds
                        .and_then(|c| c.iter().find(|x| x["type"] == t))
                        .map(|x| x["status"] == "True")
                        .unwrap_or(false)
                };
                let triggers = so["spec"]["triggers"]
                    .as_array()
                    .map(|ts| {
                        ts.iter()
                            .filter_map(|t| t["type"].as_str())
                            .collect::<Vec<_>>()
                            .join(",")
                    })
                    .unwrap_or_default();
                let replicas = snap
                    .models
                    .iter()
                    .find(|m| m.name == target)
                    .map(|m| m.ready)
                    .unwrap_or(0);
                snap.autoscalers.push(Autoscale {
                    target,
                    min,
                    max,
                    replicas,
                    ready: cond("Ready"),
                    active: cond("Active"),
                    triggers,
                });
            }
        }
    }

    collect_stored(cfg, snap).await;
    collect_compiles(cfg, snap).await;

    // artifact 저장/구동 노드 — 가속기 busy_model 우선, 없으면 파드 스케줄 노드(분리 차용으로 먼저 계산).
    let nodes: Vec<String> = snap
        .artifacts
        .iter()
        .map(|a| {
            snap.accel
                .iter()
                .find(|x| !x.busy_model.is_empty() && x.busy_model.starts_with(&a.model))
                .map(|x| x.node.clone())
                .or_else(|| {
                    snap.pods
                        .iter()
                        .find(|p| p.name.starts_with(&a.model))
                        .map(|p| p.node.clone())
                })
                .unwrap_or_default()
        })
        .collect();
    for (a, n) in snap.artifacts.iter_mut().zip(nodes) {
        a.node = n;
    }
}

/// 노드 라벨에서 NPU 드라이버/SDK 존재·버전을 읽어 NodeInfo.npu 채움.
/// 컴파일은 해당 NPU 드라이버가 설치된 노드에서만 가능 → 타깃 선택·경고에 사용.
async fn collect_node_npu(nodes: &mut [NodeInfo]) {
    let Ok(v) = kube::get_json(&["get", "nodes", "-o", "json"]).await else {
        return;
    };
    let Some(items) = v["items"].as_array() else {
        return;
    };
    for n in items {
        let name = n["metadata"]["name"].as_str().unwrap_or("");
        let Some(node) = nodes.iter_mut().find(|x| x.name == name) else {
            continue;
        };
        let l = &n["metadata"]["labels"];
        let mut parts = Vec::new();
        if let Some(prod) = l["furiosa.ai/npu.product"].as_str() {
            let drv = l["furiosa.ai/driver.version"].as_str().unwrap_or("?");
            parts.push(format!("Furiosa {} drv{}", prod.to_uppercase(), drv));
        }
        if l["rebellions.ai/npu.present"].as_str() == Some("true")
            || l.get("rebellions.ai/npu.product").is_some()
        {
            let prod = l["rebellions.ai/npu.product"].as_str().unwrap_or("RBLN");
            let drv = l["rebellions.ai/driver-version.full"]
                .as_str()
                .unwrap_or("?");
            let installed = l["rebellions.ai/npu.driver.status"].as_str() == Some("installed");
            parts.push(format!(
                "Rebellions {} drv{}{}",
                prod,
                drv,
                if installed { "" } else { "(!drv)" }
            ));
        }
        node.npu = parts.join(" · ");
    }
}

/// k8s/llm-d 이벤트(최근 40) → snap.events. collect_kube 에서 분리된 leaf 파서.
async fn collect_events(cfg: &Config, snap: &mut Snapshot) {
    if let Ok(v) = kube::get_json(&[
        "get",
        "events",
        "-n",
        &cfg.ns,
        "--sort-by=.lastTimestamp",
        "-o",
        "json",
    ])
    .await
    {
        if let Some(items) = v["items"].as_array() {
            for e in items.iter().rev().take(40) {
                let obj = format!(
                    "{}/{}",
                    e["involvedObject"]["kind"].as_str().unwrap_or(""),
                    e["involvedObject"]["name"].as_str().unwrap_or("")
                );
                snap.events.push(EventRow {
                    typ: e["type"].as_str().unwrap_or("Normal").to_string(),
                    reason: e["reason"].as_str().unwrap_or("").to_string(),
                    object: obj,
                    message: e["message"].as_str().unwrap_or("").to_string(),
                    count: e["count"].as_i64().unwrap_or(1),
                });
            }
        }
    }
}

/// Gateway 주소/상태(Programmed) → snap.gw_addr/gw_ok.
async fn collect_gateway(cfg: &Config, snap: &mut Snapshot, warn: &mut Vec<String>) {
    let r = kube::get_json(&["get", "gateway", "-n", &cfg.ns, "-o", "json"]).await;
    if let Err(e) = &r {
        kube_warn("gateway", e, warn);
    }
    if let Ok(v) = r {
        if let Some(g) = v["items"].as_array().and_then(|a| a.first()) {
            snap.gw_addr = g["status"]["addresses"][0]["value"]
                .as_str()
                .unwrap_or("")
                .to_string();
            if let Some(conds) = g["status"]["conditions"].as_array() {
                snap.gw_ok = conds
                    .iter()
                    .any(|c| c["type"] == "Programmed" && c["status"] == "True");
            }
        }
    }
}

/// 공유 스토어 인벤토리(model-inventory ConfigMap) → snap.stored. 없으면(미배포) 조용히 빈 값.
async fn collect_stored(cfg: &Config, snap: &mut Snapshot) {
    if let Ok(v) =
        kube::get_json(&["get", "cm", "model-inventory", "-n", &cfg.ns, "-o", "json"]).await
    {
        if let Some(txt) = v["data"]["inventory"].as_str() {
            snap.stored = parse_inventory(txt);
        }
        snap.store_capacity = v["data"]["capacity"]
            .as_str()
            .and_then(parse_store_capacity);
    }
}

/// Parse the scan's `"<total> <used> <avail>"` byte triple. None when absent or malformed —
/// a scan predating the capacity measurement writes nothing, and the view simply omits it.
fn parse_store_capacity(txt: &str) -> Option<StoreCapacity> {
    let mut it = txt.split_whitespace();
    let (t, u, a) = (it.next()?, it.next()?, it.next()?);
    let (total_bytes, used_bytes, avail_bytes) =
        (t.parse().ok()?, u.parse().ok()?, a.parse().ok()?);
    // A filesystem reporting zero total is not a filesystem we can say anything useful about.
    if total_bytes == 0 {
        return None;
    }
    Some(StoreCapacity {
        total_bytes,
        used_bytes,
        avail_bytes,
    })
}

/// Parse the discovery scan's pipe-separated inventory.
///
/// Format: `repo | revision | format | compiled_for | size | path [| built_with]`. The last
/// column is a later addition, so a cluster still running the older CronJob is read as before
/// rather than losing its inventory to a format bump.
fn parse_inventory(txt: &str) -> Vec<StoredModel> {
    let mut out = Vec::new();
    {
        {
            for line in txt.lines() {
                let l = line.trim();
                if l.is_empty() || l.starts_with('#') {
                    continue;
                }
                let f: Vec<&str> = l.split('|').map(|s| s.trim()).collect();
                if f.len() >= 6 {
                    out.push(StoredModel {
                        family: model_family(f[0], f[0]),
                        repo: f[0].into(),
                        revision: f[1].into(),
                        format: f[2].into(),
                        compiled_for: f[3].into(),
                        size: f[4].into(),
                        path: f[5].into(),
                        // Provenance is a later addition to the scan's output. A cluster
                        // running the older discovery CronJob publishes six fields, and must
                        // keep working rather than losing its whole inventory to a format bump.
                        built_with: f
                            .get(6)
                            .map(|x| x.trim())
                            .filter(|x| !x.is_empty())
                            .unwrap_or("-")
                            .to_string(),
                    });
                }
            }
        }
    }
    out
}

/// k8s RFC3339 타임스탬프("2026-07-03T12:34:56Z")를 epoch 초로. 실패 시 None.
/// chrono 의존 없이 고정 포맷만 파싱(k8s 는 항상 UTC 'Z').
fn parse_k8s_ts(s: &str) -> Option<u64> {
    let s = s.trim_end_matches('Z');
    let (date, time) = s.split_once('T')?;
    let mut d = date.split('-');
    let (y, mo, da): (i64, i64, i64) = (
        d.next()?.parse().ok()?,
        d.next()?.parse().ok()?,
        d.next()?.parse().ok()?,
    );
    let mut t = time.split(':');
    let (h, mi, se): (i64, i64, i64) = (
        t.next()?.parse().ok()?,
        t.next()?.parse().ok()?,
        t.next()?.split('.').next()?.parse().ok()?,
    );
    // days-from-civil (Howard Hinnant) — 1970-01-01 기준 일수.
    let y = if mo <= 2 { y - 1 } else { y };
    let era = (if y >= 0 { y } else { y - 399 }) / 400;
    let yoe = y - era * 400;
    let doy = (153 * (if mo > 2 { mo - 3 } else { mo + 9 }) + 2) / 5 + da - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    let days = era * 146097 + doe - 719468;
    let secs = days * 86400 + h * 3600 + mi * 60 + se;
    if secs < 0 {
        None
    } else {
        Some(secs as u64)
    }
}

/// 진행/최근 컴파일 Job(`compile-*`)과 프리페치 Job(`prefetch-*`) → snap.compiles. 없으면 빈 값.
/// 상태·경과·(완료 시)소요 + 활성 Job 은 파드 로그 마지막 줄을 진행 힌트로.
async fn collect_compiles(cfg: &Config, snap: &mut Snapshot) {
    let Ok(v) = kube::get_json(&["get", "jobs", "-n", &cfg.ns, "-o", "json"]).await else {
        return;
    };
    let Some(items) = v["items"].as_array() else {
        return;
    };
    let now = now_secs();
    let recorded = crate::history::recorded_ids();
    let pods = kube::get_json(&["get", "pods", "-n", &cfg.ns, "-o", "json"])
        .await
        .ok();
    for j in items {
        let name = j["metadata"]["name"].as_str().unwrap_or("");
        let is_prefetch = name.starts_with("prefetch-");
        if !name.starts_with("compile-") && !is_prefetch {
            continue;
        }
        let execution_id = crate::history::job_execution_id(&cfg.ns, &j["metadata"]);
        // 이름 = compile-{model}-{target}(target 은 "-rbln-"/"-rngd-" 부터) 또는 prefetch-{model}-hf.
        let (model, target, vendor) = if is_prefetch {
            let rest = name.strip_prefix("prefetch-").unwrap_or(name);
            let rest = rest.strip_suffix("-hf").unwrap_or(rest);
            (
                rest.to_string(),
                "download".to_string(),
                "prefetch".to_string(),
            )
        } else {
            let rest = &name["compile-".len()..];
            if let Some(i) = rest.find("-rbln-") {
                (
                    rest[..i].to_string(),
                    rest[i + 1..].to_string(),
                    "RBLN".to_string(),
                )
            } else if let Some(i) = rest.find("-rngd-") {
                (
                    rest[..i].to_string(),
                    rest[i + 1..].to_string(),
                    "RNGD".to_string(),
                )
            } else {
                (rest.to_string(), String::new(), "-".to_string())
            }
        };
        let st = &j["status"];
        let succeeded = st["succeeded"].as_i64().unwrap_or(0) >= 1;
        let active = st["active"].as_i64().unwrap_or(0) >= 1;
        let failed_cond = st["conditions"]
            .as_array()
            .map(|c| {
                c.iter()
                    .any(|x| x["type"] == "Failed" && x["status"] == "True")
            })
            .unwrap_or(false);
        let status = if succeeded {
            "Complete"
        } else if failed_cond {
            "Failed"
        } else if active {
            "Running"
        } else {
            "Pending"
        }
        .to_string();
        let start = st["startTime"].as_str().and_then(parse_k8s_ts).or_else(|| {
            j["metadata"]["creationTimestamp"]
                .as_str()
                .and_then(parse_k8s_ts)
        });
        let completion = st["completionTime"]
            .as_str()
            .and_then(parse_k8s_ts)
            .or_else(|| {
                st["conditions"]
                    .as_array()
                    .and_then(|c| {
                        c.iter()
                            .find(|x| x["type"] == "Failed")
                            .and_then(|x| x["lastTransitionTime"].as_str())
                    })
                    .and_then(parse_k8s_ts)
            });
        let age_secs = start.map(|s| now.saturating_sub(s)).unwrap_or(0);
        let duration_secs = match (start, completion) {
            (Some(s), Some(c)) if c >= s => Some(c - s),
            _ => None,
        };
        // Compile options and source come off the Job's own environment, so history records
        // what was actually built rather than re-deriving it from the name.
        let (options, source) = job_options(j);
        let pod = pods
            .as_ref()
            .and_then(|v| v["items"].as_array())
            .and_then(|items| {
                items.iter().find(|p| {
                    p["metadata"]["ownerReferences"]
                        .as_array()
                        .is_some_and(|owners| {
                            owners.iter().any(|o| {
                                o["kind"] == "Job"
                                    && o["uid"].as_str().is_some()
                                    && o["uid"] == j["metadata"]["uid"]
                            })
                        })
                })
            })
            .and_then(|p| p["metadata"]["name"].as_str())
            .map(str::to_string);

        // Read the log once for any terminal job we have not recorded yet: a failure needs its
        // cause classified before `ttlSecondsAfterFinished` removes the Job, and a *success*
        // needs its toolchain captured — a version skew is only visible against a build that
        // worked. Already-recorded jobs are skipped, so this is not a per-tick cost.
        let terminal = status == "Complete" || status == "Failed";
        let (failure, toolchain) =
            if terminal && !execution_id.is_empty() && !recorded.contains(&execution_id) {
                let log = match &pod {
                    Some(p) => kube::log_tail(&cfg.ns, p, 120).await.unwrap_or_default(),
                    None => String::new(),
                };
                let tools = crate::diagnose::toolchain(&log);
                let fail = if status == "Failed" {
                    let exit = match &pod {
                        Some(p) => kube::pod_exit_code(&cfg.ns, p).await,
                        None => None,
                    };
                    Some(crate::diagnose::classify(&log, exit))
                } else {
                    None
                };
                (fail, tools)
            } else {
                (None, BTreeMap::new())
            };

        // 진행 힌트: 활성 Job 은 파드 로그 마지막 비어있지 않은 줄. 완료/실패는 상태로 대체.
        let phase = if active {
            match &pod {
                Some(p) => kube::last_log_line(&cfg.ns, p)
                    .await
                    .unwrap_or_else(|| "starting…".to_string()),
                None => "starting…".to_string(),
            }
        } else if status == "Complete" {
            "COMPILE_DONE".to_string()
        } else if let Some(f) = &failure {
            f.line()
        } else {
            "pending…".to_string()
        };
        // 진행률: 완료=1.0, 실행 중이면 로그 줄에서 %/스텝 파싱(있으면), 없으면 None(indeterminate).
        let progress = if status == "Complete" {
            Some(1.0)
        } else if active {
            parse_progress(&phase)
        } else {
            None
        };
        snap.compiles.push(CompileJob {
            execution_id,
            name: name.to_string(),
            model,
            vendor,
            target,
            status,
            age_secs,
            duration_secs,
            phase,
            progress,
            failure,
            options,
            source,
            toolchain,
        });
    }
    record_finished_jobs(&snap.compiles);
    // 진행 중 → 최근 순: Running 먼저, 그다음 나이 어린 것.
    snap.compiles.sort_by(|a, b| {
        let rank = |s: &str| match s {
            "Running" => 0,
            "Pending" => 1,
            "Failed" => 2,
            _ => 3,
        };
        rank(&a.status)
            .cmp(&rank(&b.status))
            .then(a.age_secs.cmp(&b.age_secs))
    });
}

/// Compile options and HF source from a Job's container environment.
///
/// Read from the Job rather than parsed back out of its name: the name is a lossy summary
/// (`rbln-ca22-tp4-s8192` omits batch, attn and quantisation), and history needs the full set
/// to be able to recommend one.
fn job_options(job: &serde_json::Value) -> (BTreeMap<String, String>, String) {
    let mut opts = BTreeMap::new();
    let mut source = String::new();
    let envs = job["spec"]["template"]["spec"]["containers"][0]["env"]
        .as_array()
        .cloned()
        .unwrap_or_default();
    for e in envs {
        let (Some(k), Some(v)) = (e["name"].as_str(), e["value"].as_str()) else {
            continue;
        };
        // Map the recipe's environment names back onto form option keys.
        let key = match k {
            "MODEL_ID" | "SOURCE" => {
                source = v.to_string();
                continue;
            }
            "RBLN_TENSOR_PARALLEL_SIZE" | "TENSOR_PARALLEL_SIZE" | "TP" => "tp",
            "PIPELINE_PARALLEL_SIZE" | "PP" => "pp",
            "RBLN_MAX_SEQ_LEN" | "MAX_SEQ_LEN_TO_CAPTURE" | "MAX_LEN" => "max-len",
            "RBLN_BATCH_SIZE" | "BUCKET_BATCH_SIZE" => "batch",
            "RBLN_ATTN_IMPL" => "attn",
            "RBLN_KVCACHE_PARTITION_LEN" => "kvpart",
            "RBLN_NPU" => "npu",
            "RBLN_QUANTIZATION" | "USE_ACTIVATION_DQ" => "quant",
            "PAGED_ATTENTION_BLOCK_SIZE" => "block",
            "PREFILL_CHUNK_SIZE" => "chunk",
            _ => continue,
        };
        opts.insert(key.to_string(), v.to_string());
    }
    (opts, source)
}

/// Record how a serving deployment is actually performing, so the advisor can prefer option
/// sets that served well over ones that merely compiled.
///
/// Only under real load (`tps > 0`) — an idle deployment says nothing about its options. At
/// most one record per deployment per hour, since this runs on every collect tick.
fn record_serving(snap: &Snapshot) {
    let with_traffic: Vec<&PerfRow> = snap
        .perf_rows
        .iter()
        .filter(|r| r.tps.is_finite() && r.tps > 0.0)
        .collect();
    if with_traffic.is_empty() {
        return;
    }
    let hour = now_secs() / 3600;
    let known = crate::history::recorded_ids();
    for row in with_traffic {
        let id = format!("serve:{}:{}", row.model, hour);
        if known.contains(&id) {
            continue;
        }
        // Options and source come from the serving artifact discovered on the deployment.
        let art = snap.artifacts.iter().find(|a| a.model == row.model);
        let options: BTreeMap<String, String> = art
            .map(|a| a.opts.iter().cloned().collect())
            .unwrap_or_default();
        let vendor = art
            .map(|a| crate::app::App::vendor_for_engine(&a.engine).to_string())
            .unwrap_or_else(|| "gpu".to_string());
        let model = art
            .map(|a| {
                if a.source.is_empty() {
                    a.model.clone()
                } else {
                    a.source.clone()
                }
            })
            .unwrap_or_else(|| row.model.clone());
        crate::history::append(&crate::history::Record {
            ts: now_secs(),
            kind: "serve".into(),
            id,
            model,
            vendor,
            options,
            outcome: crate::history::Outcome::Ok,
            duration_secs: None,
            failure_kind: String::new(),
            detail: String::new(),
            tps: Some(row.tps),
            ttft_p95: Some(row.ttft_p95).filter(|v| v.is_finite()),
            toolchain: BTreeMap::new(),
        });
    }
}

/// Write a history record for each newly-finished compile Job.
///
/// Deduplicated by Job execution identity, so a Job that stays visible across many ticks is recorded once,
/// and the record outlives the Job itself — which is the whole point.
fn record_finished_jobs(jobs: &[CompileJob]) {
    let terminal: Vec<&CompileJob> = jobs
        .iter()
        .filter(|j| j.status == "Complete" || j.status == "Failed")
        .collect();
    if terminal.is_empty() {
        return;
    }
    let known = crate::history::recorded_ids();
    for j in terminal {
        if j.execution_id.is_empty() || known.contains(&j.execution_id) {
            continue;
        }
        let ok = j.status == "Complete";
        crate::history::append(&crate::history::Record {
            ts: now_secs(),
            kind: if j.name.starts_with("prefetch-") {
                "prefetch".into()
            } else {
                "compile".into()
            },
            id: j.execution_id.clone(),
            // Prefer the Job's own MODEL_ID. Falling back to the name means undoing the
            // DNS-safe encoding (`org--name`), or the family key would not match anything.
            model: if j.source.is_empty() {
                j.model.replacen("--", "/", 1)
            } else {
                j.source.clone()
            },
            vendor: crate::accel::by_id(&j.vendor)
                .map(|p| p.id.to_string())
                .unwrap_or_else(|| j.vendor.to_lowercase()),
            options: j.options.clone(),
            outcome: if ok {
                crate::history::Outcome::Ok
            } else {
                crate::history::Outcome::Fail
            },
            duration_secs: j.duration_secs,
            failure_kind: j
                .failure
                .as_ref()
                .map(|f| f.kind.to_string())
                .unwrap_or_default(),
            detail: j.failure.as_ref().map(|f| f.line()).unwrap_or_default(),
            tps: None,
            ttft_p95: None,
            toolchain: j.toolchain.clone(),
        });
    }
}

/// 컴파일 로그 한 줄에서 진행률(0.0~1.0)을 best-effort 파싱. 정규식 없이 순수 스캔.
/// 우선순위: (1) "NN%" / "NN.N%"  (2) "N/M" 스텝(양쪽 모두 숫자일 때만). 없으면 None(indeterminate).
/// tqdm("45%|██| 45/100")·"[3/8]"·"step 3 of 8"(→ "3/8" 아님, %/슬래시만) 등을 커버.
fn parse_progress(line: &str) -> Option<f32> {
    let b = line.as_bytes();
    // 1) '%' 앞의 숫자(공백 건너뜀).
    for (i, &c) in b.iter().enumerate() {
        if c == b'%' {
            // i-1 부터 역방향으로 숫자/'.' 수집.
            let mut j = i;
            while j > 0 && (b[j - 1].is_ascii_digit() || b[j - 1] == b'.') {
                j -= 1;
            }
            if j < i {
                if let Ok(v) = line[j..i].parse::<f32>() {
                    if (0.0..=100.0).contains(&v) {
                        return Some((v / 100.0).clamp(0.0, 1.0));
                    }
                }
            }
        }
    }
    // 2) "N/M" — '/' 양쪽이 모두 연속 숫자일 때만(경로/날짜 오검출 방지).
    for (i, &c) in b.iter().enumerate() {
        if c == b'/' {
            let mut l = i;
            while l > 0 && b[l - 1].is_ascii_digit() {
                l -= 1;
            }
            let mut r = i + 1;
            while r < b.len() && b[r].is_ascii_digit() {
                r += 1;
            }
            if l < i && r > i + 1 {
                let n: f32 = line[l..i].parse().unwrap_or(0.0);
                let m: f32 = line[i + 1..r].parse().unwrap_or(0.0);
                if m > 0.0 && n <= m {
                    return Some((n / m).clamp(0.0, 1.0));
                }
            }
        }
    }
    None
}

#[cfg(test)]
mod compile_progress_tests {
    use super::parse_progress;

    #[test]
    fn parses_percent() {
        assert_eq!(parse_progress("Compiling model... 45%"), Some(0.45));
        assert_eq!(parse_progress("progress 7.5% done"), Some(0.075));
        assert_eq!(parse_progress("100%|████████| complete"), Some(1.0));
    }

    #[test]
    fn parses_step_ratio() {
        assert_eq!(parse_progress("[3/8] lowering graph"), Some(0.375));
        assert_eq!(parse_progress("layer 5/5"), Some(1.0));
    }

    #[test]
    fn ignores_paths_and_plain_text() {
        assert_eq!(parse_progress("writing to /hf-cache/model"), None);
        assert_eq!(parse_progress("starting compilation…"), None);
        assert_eq!(parse_progress("loading weights"), None);
    }

    #[test]
    fn percent_wins_over_ratio() {
        // tqdm 형태: 퍼센트를 우선.
        assert_eq!(parse_progress("42%|███ | 42/100 [00:10<00:14]"), Some(0.42));
    }
}

fn match_model(deploy: &str, v_run: &BTreeMap<String, Series>) -> Option<String> {
    let norm = |s: &str| {
        s.to_lowercase()
            .chars()
            .filter(|c| c.is_alphanumeric())
            .collect::<String>()
    };
    let dn = norm(deploy);
    // 가장 "구체적인" 일치를 고른다. 첫 부분일치를 반환하면 BTreeMap 알파벳 순 때문에
    // 짧은 이름이 항상 이겨, 형제 변형(`x` vs `x-fp8`)의 메트릭이 서로 뒤바뀐다(BUG-05).
    // 우선순위: 완전일치 > 일치한 키가 긴 것 > (동률이면) 키 이름 순으로 안정 정렬.
    let mut best: Option<(u8, usize, &String)> = None;
    for k in v_run.keys() {
        let kn = norm(k);
        if kn.is_empty() || !(dn.contains(&kn) || kn.contains(&dn)) {
            continue;
        }
        let rank = (u8::from(kn == dn), kn.len(), k);
        if best.map(|b| rank > b).unwrap_or(true) {
            best = Some(rank);
        }
    }
    best.map(|(_, _, k)| k.clone())
}

fn parse_epp(text: &str) -> Option<EppCfg> {
    let v: serde_yaml::Value = serde_yaml::from_str(text).ok()?;
    let prof = &v["schedulingProfiles"][0];
    let profile = prof["name"].as_str().unwrap_or("default").to_string();
    let mut scorers = Vec::new();
    if let Some(plugins) = prof["plugins"].as_sequence() {
        for p in plugins {
            let name = p["pluginRef"].as_str().unwrap_or("").to_string();
            let w = p["weight"].as_f64().unwrap_or(1.0);
            if !name.is_empty() {
                scorers.push((name, w));
            }
        }
    }
    Some(EppCfg {
        profile,
        scorers,
        picker: "max-score-picker (default)".to_string(),
    })
}

pub fn now_secs() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn family_normalizes_hf_and_paths() {
        // HF id: org 유지 + 변형태그(quant/instruct) 제거, 소문자.
        assert_eq!(
            model_family("Qwen/Qwen2.5-0.5B-Instruct", "vllm-qwen05b-gb10"),
            "qwen/qwen2.5-0.5b"
        );
        assert_eq!(
            model_family("furiosa-ai/K-EXAONE-236B-A23B-NVFP4A16", "k-exaone-236b"),
            "furiosa-ai/exaone-236b-a23b"
        );
        // 로컬 경로: leaf 디렉터리.
        assert_eq!(model_family("/models/exaone35", "vllm-exaone"), "exaone35");
        // 소스 없음(셸 래퍼 등): deploy 이름에서 엔진/HW 접사 제거.
        assert_eq!(model_family("", "vllm-v4flash"), "v4flash");
    }

    #[test]
    fn same_model_different_builds_share_family() {
        // 같은 HF 모델의 두 배포(다른 양자화/HW)는 한 family 로 묶임.
        let a = model_family("meta-llama/Llama-3.1-8B-Instruct", "llama31-rbln");
        let b = model_family("meta-llama/Llama-3.1-8B-Instruct-FP8", "llama31-gpu");
        assert_eq!(a, b);
        assert_eq!(a, "meta-llama/llama-3.1-8b");
    }

    #[test]
    fn strip_variant_tags_drops_hw_and_precision() {
        assert_eq!(strip_variant_tags("vllm-koni-rbln"), "koni");
        assert_eq!(strip_variant_tags("Model-BF16-Instruct"), "model");
    }

    /// The volume layouts of this cluster's real Deployments, verbatim.
    ///
    /// BUG: every RBLN deployment mounts /usr/lib at /host-rbln-lib from a volume *named*
    /// `host-rbln-lib`. The old first-match picker matched "rbln" in that name and reported the
    /// model as living in /usr/lib for eight of sixteen deployments.
    #[test]
    fn model_mount_is_the_model_not_the_vendor_libraries() {
        /// (volume name, mountPath, hostPath or "" for an emptyDir).
        type Mount = (&'static str, &'static str, &'static str);
        /// (deployment, its mounts, the volume the picker must choose).
        type Case = (&'static str, &'static [Mount], &'static str);
        let cases: [Case; 4] = [
            (
                "gemma4-rbln",
                &[
                    (
                        "host-local-pkgs",
                        "/home/gspark/.local/lib/python3.10/site-packages",
                        "/home/gspark/.local/lib/python3.10/site-packages",
                    ),
                    (
                        "host-sys-local-pkgs",
                        "/host-sys-local-pkgs",
                        "/usr/local/lib/python3.10/dist-packages",
                    ),
                    (
                        "host-sys-pkgs",
                        "/host-sys-pkgs",
                        "/usr/lib/python3/dist-packages",
                    ),
                    ("host-libs", "/host-libs", "/usr/lib/x86_64-linux-gnu"),
                    ("host-rbln-lib", "/host-rbln-lib", "/usr/lib"),
                    ("host-rbln-bin", "/host-rbln-bin", "/usr/bin"),
                    (
                        "model",
                        "/model",
                        "/home/gspark/rbln-gemma4-26b-a4b-tp4-s8192",
                    ),
                    ("shm", "/dev/shm", ""),
                ],
                "model",
            ),
            (
                "sw-atom-decode-b1",
                &[
                    (
                        "local-pkgs",
                        "/home/gspark/.local/lib/python3.10/site-packages",
                        "/home/gspark/.local/lib/python3.10/site-packages",
                    ),
                    ("libs", "/host-libs", "/usr/lib/x86_64-linux-gnu"),
                    ("rbln-lib", "/host-rbln-lib", "/usr/lib"),
                    ("rbln-bin", "/host-rbln-bin", "/usr/bin"),
                    (
                        "app",
                        "/app",
                        "/home/gspark/workspace/01_pd_disag/rngd_llmd",
                    ),
                    ("hf", "/hf", "/home/gspark/.cache/huggingface"),
                    ("dshm", "/dev/shm", "/dev/shm"),
                    ("artifacts", "/artifacts", "/home/gspark/rbln-llama8b-pd"),
                ],
                "artifacts",
            ),
            (
                // No artifact directory at all: the HF cache is the best available answer.
                "hetero-pd-gateway",
                &[
                    ("rbln-lib", "/host-rbln-lib", "/usr/lib"),
                    (
                        "app",
                        "/app",
                        "/home/gspark/workspace/01_pd_disag/rngd_llmd",
                    ),
                    ("hf", "/hf", "/home/gspark/.cache/huggingface"),
                    ("dshm", "/dev/shm", "/dev/shm"),
                    ("cfg", "/cfg", ""),
                ],
                "hf",
            ),
            (
                "ds4-v4flash-gb10",
                &[
                    ("ds4bin", "/ds4", "/home/gspark/ds4"),
                    ("gguf", "/gguf", "/home/gspark/model-cache/ds4-gguf"),
                    ("kv", "/tmp/ds4-kv", ""),
                    ("dshm", "/dev/shm", ""),
                ],
                "gguf",
            ),
        ];
        for (deploy, mounts, want) in cases {
            let vms: Vec<serde_json::Value> = mounts
                .iter()
                .map(|(n, mp, _)| serde_json::json!({ "name": n, "mountPath": mp }))
                .collect();
            let vols: Vec<serde_json::Value> = mounts
                .iter()
                .map(|(n, _, hp)| {
                    if hp.is_empty() {
                        serde_json::json!({ "name": n, "emptyDir": {} })
                    } else {
                        serde_json::json!({ "name": n, "hostPath": { "path": hp } })
                    }
                })
                .collect();
            let pod = serde_json::json!({ "volumes": vols });
            let got = pick_model_mount(&vms, &pod).expect("a mount");
            assert_eq!(
                got["name"].as_str(),
                Some(want),
                "{}: picked {:?}",
                deploy,
                got["name"]
            );
        }
    }

    /// A pod whose every mount is a system directory must still report something, and a pod
    /// with no mounts at all must not panic.
    #[test]
    fn model_mount_degrades_without_a_candidate() {
        let vms = vec![
            serde_json::json!({ "name": "libs", "mountPath": "/host-libs" }),
            serde_json::json!({ "name": "bin", "mountPath": "/host-bin" }),
        ];
        let pod = serde_json::json!({ "volumes": [
            { "name": "libs", "hostPath": { "path": "/usr/lib" } },
            { "name": "bin", "hostPath": { "path": "/usr/bin" } },
        ] });
        assert_eq!(
            pick_model_mount(&vms, &pod).map(|m| m["name"].as_str()),
            Some(Some("libs")),
            "falls back to the first mount rather than reporting nothing"
        );
        assert!(pick_model_mount(&[], &pod).is_none());
    }

    /// The system-mount judgement is on the backing path, since the container-side path can
    /// look perfectly model-ish.
    #[test]
    fn system_mounts_are_judged_by_where_they_come_from() {
        assert!(is_system_mount("/host-rbln-lib", Some("/usr/lib")));
        assert!(is_system_mount(
            "/model",
            Some("/usr/lib/python3/dist-packages")
        ));
        assert!(is_system_mount(
            "/home/gspark/.local/lib/python3.10/site-packages",
            None
        ));
        assert!(is_system_mount("/dev/shm", None));
        // A real model directory under a home directory is not a system mount.
        assert!(!is_system_mount(
            "/model",
            Some("/home/gspark/rbln-gemma4-26b-a4b-tp4-s8192")
        ));
        assert!(!is_system_mount("/model-cache", None));
    }

    /// The exact string the cluster's scan publishes, and the ways it can be absent.
    #[test]
    fn store_capacity_parses_and_degrades() {
        // Measured on the real store: 52.3T total, 6.4T used, 45.9T available.
        let c = parse_store_capacity("57504801730560 7038588125184 50466213605376")
            .expect("the live format must parse");
        assert_eq!(c.total_bytes, 57_504_801_730_560);
        assert_eq!(c.used_bytes, 7_038_588_125_184);
        assert_eq!(c.avail_bytes, 50_466_213_605_376);
        // df -h reports 12% used; used/(used+avail) must land there.
        assert!(
            (c.used_pct() - 12.24).abs() < 0.1,
            "used_pct was {}",
            c.used_pct()
        );

        // A scan predating the measurement writes an empty file, and older scans write no key.
        assert!(parse_store_capacity("").is_none());
        assert!(parse_store_capacity("   \n").is_none());
        // Malformed input must not become a misleading zero-capacity bar.
        assert!(parse_store_capacity("1 2").is_none(), "too few fields");
        assert!(parse_store_capacity("a b c").is_none(), "non-numeric");
        assert!(
            parse_store_capacity("0 0 0").is_none(),
            "zero total says nothing"
        );
    }

    /// A full store must not divide by zero, and a store with no reserved blocks must read 100%.
    #[test]
    fn store_capacity_pct_edges() {
        let full = StoreCapacity {
            total_bytes: 100,
            used_bytes: 100,
            avail_bytes: 0,
        };
        assert!((full.used_pct() - 100.0).abs() < f64::EPSILON);
        let empty = StoreCapacity {
            total_bytes: 100,
            used_bytes: 0,
            avail_bytes: 0,
        };
        assert_eq!(empty.used_pct(), 0.0, "must not divide by zero");
    }

    /// The exact bytes the cluster's discovery CronJob publishes today, plus the seventh
    /// column it publishes after the provenance change. Both must parse.
    #[test]
    fn inventory_parses_with_and_without_provenance() {
        // Six columns: what a cluster running the older scan emits.
        let old = "\
# repo | revision | format | compiled_for | size | path
furiosa-ai/Qwen3-4B-FP8 | - | furiosa | rngd-tp8-pp1-s8192 | 109M | compiled/furiosa-ai--Qwen3-4B-FP8/furiosa/rngd-tp8-pp1-s8192/
";
        let rows = parse_inventory(old);
        assert_eq!(rows.len(), 1, "comment line must be skipped");
        assert_eq!(rows[0].repo, "furiosa-ai/Qwen3-4B-FP8");
        assert_eq!(rows[0].size, "109M");
        assert_eq!(
            rows[0].built_with, "-",
            "an older inventory must read as unknown provenance, not drop the row"
        );

        // Seven columns, both vendors, as the updated scan emits them.
        let new = "\
# repo | revision | format | compiled_for | size | path | built_with
furiosa-ai/Qwen3-4B-FP8 | - | furiosa | rngd-tp8-pp1-s8192 | 109M | compiled/a/furiosa/x/ | furiosa-compiler=2026.3.0
KISTI-KONI/KONI | - | rbln | RBLN-CA22-tp4-s8192 | 20G | compiled/b/rbln/y/ | optimum-rbln=0.10.2
meta-llama/L | main | hf | - | 16G | hub/models--meta-llama--L/snapshots/abc/ | -
";
        let rows = parse_inventory(new);
        assert_eq!(rows.len(), 3);
        assert_eq!(rows[0].built_with, "furiosa-compiler=2026.3.0");
        assert_eq!(rows[1].built_with, "optimum-rbln=0.10.2");
        assert_eq!(
            rows[2].built_with, "-",
            "source weights have no compiler, and an explicit - must stay unknown"
        );
        // The added column must not disturb the columns before it.
        assert_eq!(rows[1].compiled_for, "RBLN-CA22-tp4-s8192");
        assert_eq!(rows[1].path, "compiled/b/rbln/y/");
    }

    /// A blank seventh column (a scan that found no version) must read as unknown rather than
    /// as an empty string that would render as a gap.
    #[test]
    fn inventory_treats_a_blank_provenance_column_as_unknown() {
        let rows = parse_inventory("org/n | - | rbln | tp4 | 1G | compiled/x/rbln/tp4/ |  \n");
        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0].built_with, "-");
    }

    #[test]
    fn to_gb_handles_missing() {
        assert_eq!(to_gb(2.0e9), 2.0);
        assert_eq!(to_gb(f64::NAN), 0.0); // NaN → 0
    }

    #[test]
    fn match_model_fuzzy() {
        let mut m: BTreeMap<String, Series> = BTreeMap::new();
        m.insert(
            "koni-llama3.1-8b".into(),
            Series {
                labels: BTreeMap::new(),
                value: 1.0,
            },
        );
        // 비영숫자 무시 매칭: "koni-llama31-8b-rbln" ⊃ "konillama318b"
        assert_eq!(
            match_model("koni-llama31-8b-rbln", &m).as_deref(),
            Some("koni-llama3.1-8b")
        );
        assert_eq!(match_model("totally-different", &m), None);
    }

    #[test]
    fn match_model_prefers_most_specific_sibling() {
        // BUG-05 회귀: `x` 와 `x-fp8` 을 동시 서빙할 때 각 배포가 자기 메트릭을 받아야 한다.
        let mut m: BTreeMap<String, Series> = BTreeMap::new();
        for k in ["qwen3-4b", "qwen3-4b-fp8"] {
            m.insert(
                k.into(),
                Series {
                    labels: BTreeMap::new(),
                    value: 1.0,
                },
            );
        }
        assert_eq!(
            match_model("qwen3-4b-fp8", &m).as_deref(),
            Some("qwen3-4b-fp8")
        );
        assert_eq!(match_model("qwen3-4b", &m).as_deref(), Some("qwen3-4b"));
        // 접두 배포명(서빙 래퍼)도 자기 변형으로 붙어야 한다.
        assert_eq!(
            match_model("serve-qwen3-4b-fp8", &m).as_deref(),
            Some("qwen3-4b-fp8")
        );
    }

    #[test]
    fn parse_epp_scorers() {
        let yaml = "schedulingProfiles:\n  - name: default\n    plugins:\n      - pluginRef: kv-cache-scorer\n        weight: 2\n      - pluginRef: queue-scorer\n        weight: 1\n";
        let cfg = parse_epp(yaml).expect("parses");
        assert_eq!(cfg.profile, "default");
        assert_eq!(cfg.scorers.len(), 2);
        assert_eq!(cfg.scorers[0], ("kv-cache-scorer".to_string(), 2.0));
        // 프로파일 없는 입력은 graceful — scorers 빈 EppCfg.
        assert_eq!(parse_epp("42").map(|c| c.scorers.len()), Some(0));
    }

    #[test]
    fn model_container_skips_sidecar() {
        // 프록시 사이드카가 [0], vLLM 모델서버가 [1] → 모델서버 선택.
        let spec = serde_json::json!({
            "containers": [
                { "name": "proxy", "image": "envoyproxy/envoy:v1", "args": [] },
                { "name": "server", "image": "vllm/vllm-openai", "args": ["--model", "/models/x"] }
            ]
        });
        let c = model_container(&spec);
        assert_eq!(c["name"].as_str(), Some("server"));
    }
}
