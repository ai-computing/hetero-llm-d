//! Deploy▸Zoo — 벤더(Furiosa/Rebellions) 모델 zoo. 공개 HF 모델을 브라우징하고
//! ⏎ 로 Prefetch(가중치 사전 다운로드)·Compile→벤더. 컴파일본이 스토어에 생기면
//! Deploy▸Library 에서 배포한다(배포는 컴파일 산출물 기준이므로 흐름을 분리).
//! 컴파일 가능 벤더는 [[npu-compat]](src/npu-compat.json) 패밀리 지원에서 자동 판정.

use super::*;
use crate::manifest::{args, env_secret, env_val, mount, s, seq, Doc, Manifest};

/// Prefetch recipe, embedded from `assets/recipes/`. Takes every parameter through the
/// environment, so the model id and revision are never spliced into a script.
const RECIPE_PREFETCH: &str = include_str!("../../assets/recipes/hf-prefetch.sh");

impl App {
    /// 현재 Zoo 뷰(상단 패널)에서 선택된 모델(정렬·필터 반영). 하단 Activity 패널이면 None.
    pub(super) fn selected_zoo(&self) -> Option<&crate::catalog::ZooModel> {
        if self.view != View::Zoo || self.panel_focus != 0 {
            return None;
        }
        self.sel_orig().and_then(|i| self.zoo.get(i))
    }

    /// 이 zoo 모델을 컴파일할 수 있는 벤더들(compat 기반). 없으면 GPU 직서빙만 가능.
    pub fn zoo_vendors(source: &str) -> Vec<&'static str> {
        crate::compat::compilable_vendors(source)
    }

    /// 스토어에 이미 이 모델의 컴파일본이 있는가(repo 매칭). Deploy 안내용.
    pub fn zoo_in_store(&self, source: &str) -> bool {
        let repo = source.to_lowercase();
        let short = repo.rsplit('/').next().unwrap_or(&repo);
        self.snap
            .stored
            .iter()
            .any(|s| s.repo.to_lowercase() == repo || s.repo.to_lowercase().contains(short))
    }

    /// 모델의 상황별 상태(Zoo STATUS 열) — 스토어/컴파일중/프리페치중/게이트/미확보.
    /// 반환 `(label, sev)`: sev 0=built, 1=진행중, 2=게이트(토큰필요), 3=available.
    pub fn zoo_state(&self, z: &crate::catalog::ZooModel) -> (&'static str, u8) {
        if self.zoo_in_store(&z.source) {
            return ("● built", 0);
        }
        let repo = z.source.to_lowercase().replace('/', "--");
        let active = |prefetch: bool| {
            self.snap.compiles.iter().any(|c| {
                (c.vendor == "prefetch") == prefetch
                    && (c.status == "Running" || c.status == "Pending")
                    && c.name.to_lowercase().contains(&repo)
            })
        };
        if active(false) {
            return ("◐ compiling", 1);
        }
        if active(true) {
            return ("⇊ prefetch", 1);
        }
        if z.note.to_lowercase().contains("gated") {
            return ("⇩ gated", 2);
        }
        ("○ available", 3)
    }

    /// 선택 zoo 모델 → 컴파일 흐름이 쓰는 합성 아티팩트(첫 컴파일 벤더 기준).
    pub(super) fn selected_zoo_artifact(&self) -> Option<crate::collect::ModelArtifact> {
        let z = self.selected_zoo()?;
        let vendor = Self::zoo_vendors(&z.source)
            .first()
            .copied()
            .unwrap_or("gpu");
        Some(Self::synthetic_artifact_for(
            &z.source,
            vendor,
            String::new(),
            &[],
        ))
    }

    /// Prefetch 폼 — 다운로드 대상(저장소 PVC·경로·리비전)을 고른 뒤 Job 을 만든다.
    /// 사용자가 "어디에 저장할지"를 명시적으로 정하도록(기본 model-store PVC 의 hub/ 캐시).
    pub fn open_prefetch_form(&mut self) {
        let Some(z) = self.selected_zoo() else {
            return;
        };
        // 후보 PVC — 스토어 PVC 는 항상, 그 외 "클러스터에 실존하는" PVC 만 추가.
        // (예전엔 rbln-artifacts/furiosa-artifacts 를 실존 여부와 무관하게 넣어, 없는 PVC 로 Job 을 만들면
        //  pod 가 영구 Pending(FailedScheduling)이 됐다. 이제 관측된 PVC 만 제시한다.)
        let mut pvcs = vec!["model-store".to_string()];
        for name in &self.snap.pvcs {
            if !pvcs.iter().any(|p| p == name) {
                pvcs.push(name.clone());
            }
        }
        let field =
            |key: &str, label: &str, value: &str, choices: Vec<String>, help: &str| CompileField {
                key: key.into(),
                label: label.into(),
                value: value.into(),
                choices,
                numeric: false,
                help: help.into(),
            };
        let _ = &pvcs; // 목적지 PVC 는 폼 필드가 아니라 2단계 picker(open_prefetch_dest_picker)에서 고른다
        let fields = vec![
            field(
                "dir",
                "cache dir",
                "hub",
                ["hub", "models", "prefetch"].iter().map(|s| s.to_string()).collect(),
                "Sub-path under the chosen PVC for the HF cache (HF_HOME=/mnt/store/<dir>). e to edit.",
            ),
            field(
                "revision",
                "revision",
                "main",
                vec!["main".to_string()],
                "HF revision/branch/tag to download. e to edit.",
            ),
        ];
        self.prefetch_form = Some(CompileForm {
            model: z.display.clone(),
            model_id: z.source.clone(),
            vendor: "prefetch",
            engine: String::new(),
            fields,
            cursor: 0,
            editing: false,
            dest: String::new(),
        });
    }

    /// Prefetch 목적지(저장 PVC) picker — 2단계. model-store(항상) + 관측된 RWX PVC.
    pub fn open_prefetch_dest_picker(&mut self) {
        if self.prefetch_form.is_none() {
            return;
        }
        let mut pvcs = vec!["model-store".to_string()];
        for name in &self.snap.pvcs {
            if !pvcs.iter().any(|p| p == name) {
                pvcs.push(name.clone());
            }
        }
        let observed = &self.snap.pvcs;
        let rows: Vec<PlaceRow> = pvcs
            .iter()
            .map(|name| {
                // 관측 목록이 있으면 실존 여부 표시(없으면 미관측 → 통과, prefetch_form_submit 이 최종 검증).
                let exists = observed.is_empty() || observed.iter().any(|p| p == name);
                PlaceRow {
                    value: name.clone(),
                    label: name.clone(),
                    free: 0,
                    total: 0,
                    util: f64::NAN,
                    mem_used: 0.0,
                    mem_total: 0.0,
                    schedulable: exists,
                    note: if exists {
                        "RWX store — 가중치 저장, compile/serve 재사용".to_string()
                    } else {
                        "관측되지 않은 PVC (없으면 prefetch 차단)".to_string()
                    },
                    info_only: true,
                }
            })
            .collect();
        self.place_picker = Some(PlacePick { cursor: 0, rows });
    }

    /// Prefetch 폼 확정 → 선택 PVC/경로로 HF 가중치를 받는 Job 생성(확인 팝업).
    pub fn prefetch_form_submit(&mut self) {
        let Some(form) = self.prefetch_form.take() else {
            return;
        };
        let source = form.model_id.clone();
        // 목적지 PVC 는 2단계 picker(form.dest)에서 옴. 빈 값이면 기본 store.
        let pvc = {
            let p = form.dest.clone();
            if p.trim().is_empty() {
                "model-store".to_string()
            } else {
                p
            }
        };
        // PVC 존재 검증 — 없는 PVC 로 Job 을 만들면 pod 가 영구 Pending(FailedScheduling: "pvc not found")이 되고
        // Warning 이벤트를 계속 뿜는다. 관측된 목록이 있을 때만 검증(빈 목록=미관측 → 오탐 방지 위해 통과).
        if !self.snap.pvcs.is_empty() && !self.snap.pvcs.iter().any(|p| p == &pvc) {
            self.notify_bad(format!(
                "PVC '{}' 없음 — prefetch 취소. 존재하는 PVC를 고르거나 먼저 생성하세요.",
                pvc
            ));
            return;
        }
        let dir = {
            let d = form.get("dir");
            if d.trim().is_empty() {
                "hub".to_string()
            } else {
                d
            }
        };
        let revision = form.get("revision");
        // A revision names a git ref; anything else is a typo that would only waste a Job.
        // (It is env-passed now, so this is validation rather than escaping.)
        if !revision.trim().is_empty()
            && !revision
                .chars()
                .all(|c| c.is_ascii_alphanumeric() || matches!(c, '.' | '_' | '-' | '/'))
        {
            self.notify_bad(format!(
                "revision '{}' is not a valid git ref — prefetch cancelled",
                revision
            ));
            return;
        }
        let repo_dir = source.replace('/', "--");
        let name = job_name("prefetch", &repo_dir, "");
        let hf_home = format!("/mnt/store/{}", dir.trim_matches('/'));
        let model_dir = format!("{}/hub/models--{}", hf_home, repo_dir);
        let rev_label = if revision.trim().is_empty() {
            "main".to_string()
        } else {
            revision.clone()
        };
        let cm_name = format!("{}-script", name);

        let job = crate::ymap! {
            "apiVersion" => s("batch/v1"),
            "kind" => s("Job"),
            "metadata" => crate::ymap! {
                "name" => s(name.clone()),
                "namespace" => s(&self.ns),
                "labels" => crate::ymap! { "app.kubernetes.io/component" => s("prefetch") },
            },
            "spec" => crate::ymap! {
                "backoffLimit" => serde_yaml::Value::from(0),
                // Same reasoning as the compile Job: outlive the gap between two runs of the
                // tool, so a failed download is still there to be recorded and read.
                "ttlSecondsAfterFinished" => serde_yaml::Value::from(86_400),
                "template" => crate::ymap! {
                    "spec" => crate::ymap! {
                        "restartPolicy" => s("Never"),
                        "volumes" => seq(vec![
                            crate::ymap! {
                                "name" => s("store"),
                                "persistentVolumeClaim" => crate::ymap! { "claimName" => s(pvc.clone()) },
                            },
                            crate::ymap! {
                                "name" => s("script"),
                                "configMap" => crate::ymap! { "name" => s(cm_name.clone()) },
                            },
                        ]),
                        "containers" => seq(vec![crate::ymap! {
                            "name" => s("prefetch"),
                            "image" => s("python:3.10-slim"),
                            "command" => args(["sh", "/scripts/prefetch.sh"]),
                            "env" => seq(vec![
                                env_secret("HF_TOKEN", "hf-token", "HF_TOKEN", true),
                                env_val("SOURCE", source.clone()),
                                env_val("HF_HOME", hf_home.clone()),
                                env_val("MODEL_DIR", model_dir),
                                env_val("REVISION", if rev_label == "main" { String::new() } else { rev_label.clone() }),
                                env_val("HF_HUB_ENABLE_HF_TRANSFER", "0"),
                            ]),
                            "resources" => crate::ymap! {
                                "requests" => crate::ymap! { "cpu" => s("2"), "memory" => s("4Gi") },
                            },
                            "volumeMounts" => seq(vec![
                                mount("store", "/mnt/store", false),
                                mount("script", "/scripts", true),
                            ]),
                        }]),
                    },
                },
            },
        };
        let config_map = crate::ymap! {
            "apiVersion" => s("v1"),
            "kind" => s("ConfigMap"),
            "metadata" => crate::ymap! { "name" => s(cm_name), "namespace" => s(&self.ns) },
            "data" => crate::ymap! { "prefetch.sh" => s(RECIPE_PREFETCH) },
        };
        let yaml = Manifest::new()
            .note(format!("Prefetch Job — download HF weights for {}", source))
            .note(format!(
                "  destination: PVC '{}' at {}  (reused by compile/serve as HF_HOME)",
                pvc, hf_home
            ))
            .note(format!("  revision:    {}", rev_label))
            .note("Review, then apply. Progress shows in Deploy▸Zoo/Library Activity.")
            .push(Doc::new(config_map).note("Prefetch recipe, mounted at /scripts."))
            .push(Doc::new(job))
            .to_yaml();
        self.confirm = Some(Pending::Apply {
            title: format!("prefetch {} → {}:{}", source, pvc, hf_home),
            yaml,
        });
        self.confirm_yes = false;
    }
}

#[cfg(test)]
mod zoo_tests {
    use super::*;

    #[test]
    fn bundled_zoo_loads_and_has_valid_hf_ids() {
        let a = App::new();
        assert!(!a.zoo.is_empty(), "bundled zoo.yaml should load");
        // 모든 source 는 org/name 형태(HF repo id) 여야 compile/prefetch 가 동작.
        for z in &a.zoo {
            assert!(
                z.source.contains('/'),
                "zoo source must be an HF repo id: {}",
                z.source
            );
        }
    }

    #[test]
    fn zoo_vendors_derived_from_compat() {
        // Llama 는 RBLN·Furiosa 둘 다 컴파일 가능.
        let v = App::zoo_vendors("meta-llama/Llama-3.1-8B-Instruct");
        assert!(
            v.contains(&"rbln") || v.contains(&"furiosa"),
            "Llama should be compilable"
        );
    }

    #[test]
    fn prefetch_form_builds_snapshot_download_job_with_chosen_dest() {
        let mut a = App::new();
        a.view = View::Zoo;
        a.selected = 0;
        a.open_prefetch_form();
        assert!(
            a.prefetch_form.is_some(),
            "prefetch opens a destination form"
        );
        // 대상 경로를 사용자가 바꿔도 반영되는지: dir=models 로 변경.
        if let Some(f) = a.prefetch_form.as_mut() {
            if let Some(d) = f.fields.iter_mut().find(|x| x.key == "dir") {
                d.value = "models".into();
            }
        }
        a.prefetch_form_submit();
        match a.confirm {
            Some(Pending::Apply {
                ref yaml,
                ref title,
            }) => {
                let docs: Vec<serde_yaml::Value> = serde_yaml::Deserializer::from_str(yaml)
                    .map(|d| {
                        <serde_yaml::Value as serde::Deserialize>::deserialize(d)
                            .expect("prefetch manifest is valid YAML")
                    })
                    .filter(|v: &serde_yaml::Value| !v.is_null())
                    .collect();
                let job = docs
                    .iter()
                    .find(|d| d["kind"].as_str() == Some("Job"))
                    .expect("a prefetch Job");
                let cm = docs
                    .iter()
                    .find(|d| d["kind"].as_str() == Some("ConfigMap"))
                    .expect("the recipe ConfigMap");
                let recipe = cm["data"]["prefetch.sh"].as_str().expect("prefetch.sh");
                assert!(
                    recipe.contains("snapshot_download"),
                    "recipe downloads the snapshot"
                );
                assert!(
                    recipe.contains("os.environ[\"SOURCE\"]"),
                    "recipe reads the repo id from the environment, not interpolation"
                );
                let pod = &job["spec"]["template"]["spec"];
                let env: std::collections::BTreeMap<&str, &str> = pod["containers"][0]["env"]
                    .as_sequence()
                    .expect("env")
                    .iter()
                    .filter_map(|e| {
                        Some((e["name"].as_str()?, e["value"].as_str().unwrap_or("<ref>")))
                    })
                    .collect();
                assert_eq!(
                    env.get("HF_HOME"),
                    Some(&"/mnt/store/models"),
                    "chosen dir reflected in HF_HOME"
                );
                let claims: Vec<&str> = pod["volumes"]
                    .as_sequence()
                    .expect("volumes")
                    .iter()
                    .filter_map(|v| v["persistentVolumeClaim"]["claimName"].as_str())
                    .collect();
                assert_eq!(claims, vec!["model-store"]);
                assert!(
                    title.contains("/mnt/store/models"),
                    "destination shown in title"
                );
            }
            _ => panic!("prefetch should stage a Pending::Apply Job"),
        }
    }

    #[test]
    fn prefetch_blocks_nonexistent_pvc() {
        // 관측된 PVC 목록이 있는데 그 안에 없는 PVC 로 prefetch 하면 Job 을 만들지 않고 빨강 토스트로 차단.
        // (없는 PVC 로 만든 pod 는 영구 Pending → FailedScheduling Warning 이벤트를 뿜는 회귀를 방지.)
        let mut a = App::new();
        a.view = View::Zoo;
        a.selected = 0;
        a.snap.pvcs = vec!["model-store".into()]; // 클러스터에 model-store 만 실존
        a.open_prefetch_form();
        // 목적지 picker(2단계)에서 존재하지 않는 PVC 를 dest 로 선택한 상황.
        if let Some(f) = a.prefetch_form.as_mut() {
            f.dest = "furiosa-artifacts".into();
        }
        a.prefetch_form_submit();
        assert!(
            a.confirm.is_none(),
            "없는 PVC 는 Job 을 staging 하지 않아야 한다"
        );
        assert!(a.toast_bad, "차단은 빨강 토스트로 알린다");
        assert!(
            a.toast
                .as_deref()
                .unwrap_or("")
                .contains("furiosa-artifacts"),
            "토스트에 문제 PVC 이름이 보여야 한다"
        );
    }

    #[test]
    fn prefetch_dest_picker_offers_only_observed_pvcs() {
        // 목적지 picker(2단계) 후보는 model-store(항상) + 관측된 PVC 만. 하드코딩된 이름 없음.
        let mut a = App::new();
        a.view = View::Zoo;
        a.selected = 0;
        a.snap.pvcs = vec!["model-store".into(), "rbln-artifacts".into()];
        a.open_prefetch_form();
        a.open_prefetch_dest_picker();
        let rows: Vec<String> = a
            .place_picker
            .as_ref()
            .map(|p| p.rows.iter().map(|r| r.value.clone()).collect())
            .unwrap_or_default();
        assert!(rows.contains(&"model-store".to_string()));
        assert!(
            rows.contains(&"rbln-artifacts".to_string()),
            "관측된 PVC 는 후보에 포함"
        );
        assert!(
            !rows.contains(&"furiosa-artifacts".to_string()),
            "관측되지 않은 PVC 는 후보에 없어야 한다"
        );
    }

    #[test]
    fn merge_zoo_dedups_by_source() {
        use crate::catalog::{merge_zoo, ZooModel};
        let z = |s: &str| ZooModel {
            display: s.into(),
            source: s.into(),
            role: "chat".into(),
            vendor: "furiosa".into(),
            note: String::new(),
        };
        let base = vec![z("furiosa-ai/A"), z("furiosa-ai/B")];
        let live = vec![z("furiosa-ai/B"), z("furiosa-ai/C")]; // B dup, C new
        let merged = merge_zoo(base, live);
        let ids: Vec<_> = merged.iter().map(|m| m.source.clone()).collect();
        assert_eq!(ids, vec!["furiosa-ai/A", "furiosa-ai/B", "furiosa-ai/C"]);
    }

    #[test]
    fn zoo_compile_resolves_source_to_valid_hf_id() {
        // Zoo 선택 → 컴파일 폼이 유효한 HF MODEL_ID 를 만든다(bare name 404 회귀 방지).
        let mut a = App::new();
        a.view = View::Zoo;
        a.selected = 0;
        let art = a.selected_zoo_artifact().expect("zoo artifact");
        assert!(
            App::artifact_model_id(&art).contains('/'),
            "compile model_id must be an HF id"
        );
    }
}
