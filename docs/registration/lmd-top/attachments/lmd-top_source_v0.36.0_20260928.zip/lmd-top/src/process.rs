//! Bounded subprocess execution shared by collectors and operation workers.
use anyhow::{anyhow, Result};
use std::ffi::OsStr;
use std::process::{Output, Stdio};
use std::time::Duration;
use tokio::io::AsyncWriteExt;
use tokio::process::Command;

pub async fn run(mut cmd: Command, input: Option<Vec<u8>>, budget: Duration) -> Result<Output> {
    cmd.kill_on_drop(true)
        .stdin(if input.is_some() {
            Stdio::piped()
        } else {
            Stdio::null()
        })
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    let program = cmd.as_std().get_program().to_string_lossy().into_owned();
    let mut child = cmd.spawn().map_err(|e| {
        if e.kind() == std::io::ErrorKind::NotFound {
            anyhow!("{program} not found in PATH — install it or fix PATH")
        } else {
            anyhow!("cannot start {program}: {e}")
        }
    })?;
    let mut stdin = child.stdin.take();
    let stdout = child.stdout.take();
    let stderr = child.stderr.take();
    // Read both pipes while writing stdin, avoiding pipe-capacity deadlocks.
    let io = async {
        async fn read(pipe: Option<impl tokio::io::AsyncRead + Unpin>) -> std::io::Result<Vec<u8>> {
            use tokio::io::AsyncReadExt;
            let mut bytes = Vec::new();
            if let Some(mut pipe) = pipe {
                pipe.read_to_end(&mut bytes).await?;
            }
            Ok(bytes)
        }
        let write = async {
            if let (Some(stdin), Some(input)) = (stdin.as_mut(), input) {
                stdin.write_all(&input).await?;
                stdin.shutdown().await?;
            }
            // Close the actual pipe: shutdown alone need not drop the handle.
            drop(stdin.take());
            Ok::<(), std::io::Error>(())
        };
        let (_, stdout, stderr, status) =
            tokio::try_join!(write, read(stdout), read(stderr), child.wait())?;
        Ok::<_, std::io::Error>(Output {
            status,
            stdout,
            stderr,
        })
    };
    match tokio::time::timeout(budget, io).await {
        Ok(Ok(output)) => Ok(output),
        result => {
            // Explicitly reap; kill_on_drop also covers cancellation of this future.
            let _ = child.kill().await;
            match result {
                Ok(Err(e)) => Err(e.into()),
                _ => Err(anyhow!(
                    "subprocess timed out after {}s",
                    budget.as_secs_f64()
                )),
            }
        }
    }
}

/// Synchronous facade for the TUI's worker threads and headless commands. The dedicated
/// runtime thread also permits use from an async CLI without nesting Tokio runtimes.
pub struct BlockingCommand {
    command: Option<Command>,
    input: Option<Vec<u8>>,
    budget: Duration,
}
impl BlockingCommand {
    pub fn new(program: impl AsRef<OsStr>) -> Self {
        Self {
            command: Some(Command::new(program)),
            input: None,
            budget: Duration::from_secs(25),
        }
    }
    pub fn args<I, S>(&mut self, args: I) -> &mut Self
    where
        I: IntoIterator<Item = S>,
        S: AsRef<OsStr>,
    {
        self.command.as_mut().unwrap().args(args);
        self
    }
    pub fn arg(&mut self, arg: impl AsRef<OsStr>) -> &mut Self {
        self.command.as_mut().unwrap().arg(arg);
        self
    }
    pub fn input(&mut self, input: &[u8]) -> &mut Self {
        self.input = Some(input.to_vec());
        self
    }
    pub fn budget(&mut self, budget: Duration) -> &mut Self {
        self.budget = budget;
        self
    }
    pub fn output(&mut self) -> Result<Output> {
        let cmd = self
            .command
            .take()
            .ok_or_else(|| anyhow!("command already executed"))?;
        let input = self.input.take();
        let budget = self.budget;
        std::thread::spawn(move || {
            tokio::runtime::Builder::new_current_thread()
                .enable_all()
                .build()?
                .block_on(run(cmd, input, budget))
        })
        .join()
        .map_err(|_| anyhow!("subprocess worker panicked"))?
    }
}

#[cfg(all(test, unix))]
mod tests {
    use super::*;
    #[test]
    fn captures_output_and_closes_stdin() {
        let out = BlockingCommand::new("sh")
            .args(["-c", "cat; printf err >&2; exit 7"])
            .input(b"hello")
            .output()
            .unwrap();
        assert_eq!(out.stdout, b"hello");
        assert_eq!(out.stderr, b"err");
        assert_eq!(out.status.code(), Some(7));
    }
    #[test]
    fn timeout_kills_and_reaps_child() {
        let start = std::time::Instant::now();
        let err = BlockingCommand::new("sh")
            .args(["-c", "exec sleep 10"])
            .budget(Duration::from_millis(100))
            .output()
            .unwrap_err();
        assert!(err.to_string().contains("timed out"));
        assert!(start.elapsed() < Duration::from_secs(3));
    }
}
