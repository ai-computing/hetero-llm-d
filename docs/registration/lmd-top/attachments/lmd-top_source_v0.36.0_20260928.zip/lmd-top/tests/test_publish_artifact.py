import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

path = Path(__file__).resolve().parents[1] / "assets/recipes/publish-artifact.py"
spec = importlib.util.spec_from_file_location("publish_artifact", path)
publisher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(publisher)


class PublishArtifactTests(unittest.TestCase):
    def test_complete_build_published_without_overwriting(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source, destination = root / "source", root / "store/build"
            source.mkdir()
            (source / "weights").write_text("first")
            publisher.publish(source, destination)
            self.assertEqual((destination / "weights").read_text(), "first")
            self.assertTrue((destination / "lmd-build.json").exists())
            (source / "weights").write_text("replacement")
            with self.assertRaises(FileExistsError):
                publisher.publish(source, destination)
            self.assertEqual((destination / "weights").read_text(), "first")
            self.assertEqual(list(destination.parent.iterdir()), [destination])

    def test_copy_failure_never_exposes_partial_build(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source, destination = root / "source", root / "store/build"
            source.mkdir()
            (source / "weights").write_text("data")
            with patch.object(publisher.shutil, "copytree", side_effect=OSError("disk full")):
                with self.assertRaises(OSError):
                    publisher.publish(source, destination)
            self.assertFalse(destination.exists())
            self.assertEqual(list(destination.parent.iterdir()), [])

    def test_concurrent_publisher_lock_is_not_removed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            lock = root / ".lmd-publish-build.lock"
            lock.mkdir()
            with self.assertRaises(FileExistsError):
                publisher.publish(root / "source", root / "build")
            self.assertTrue(lock.exists())
