# lmd-top — ROADMAP

> **2026-09-18 업데이트**: 설치·유지보수 개선은 [CHANGELOG](CHANGELOG.md)의 Unreleased, 신규 이종/NPU 분석 우선순위는 [설계안](docs/HETEROGENEOUS-ANALYSIS.md)을 기준으로 한다. 아래 Phase/Track 항목에는 과거 기획 상태가 포함되어 있다.

> **명제**: lmd-top 은 "Kubernetes 리소스 뷰어"가 아니라 **LLM inference 운영 콘솔**이다 —
> TTFT/TPOT/SLO · KV-cache/prefix routing · Prefill/Decode disaggregation · EPP routing decision 을
> 한 화면에서 보고 **조정**한다. (k9s/btop/nvtop/kubectl 과의 차별점은 전부 여기서 나온다.)

llm-d = Kubernetes-native distributed inference stack (vLLM/SGLang 를 클러스터 production serving 으로 확장).
핵심 요소: **Inference Gateway + EPP scheduler · ModelService · KV-cache aware routing · disaggregated serving**.

> **문서 역할 분리**: 공개 소개는 `README.md`(영어), 릴리스 이력은 `CHANGELOG.md`,
> **이 문서는 방향·우선순위(내부 기획)** 만 다룬다.

---

## 현재 상태 — Phase 1 (Monitor) ✅ 완료 (v0.31)

10개 상관 뷰 + 능동 알림 + 액션 + 배포 라이프사이클 관측까지 갖춘 **성숙한 관측 도구**.
더는 "폴리시"가 병목이 아니며, 다음 노력은 **차별화 기능(아래)과 컨트롤 플레인**으로 옮겨간다.

**출시된 뷰(0–9)**: Overview(Σ·LED 그리드·VRAM 구성 바·**Status 진단 밴드**·EPP 경로) · Accel(per-device + braille 타임라인) ·
Models(deploy 기반, `service` 조인) · EPP(scorer/weight/picker + 요청분배) · **Flow**(Gateway→route→pool + SLO/autoscale + **EPP 우회 진단**) ·
Pods · Perf(구간별 p95 **QUEUE→PREFILL→DECODE→TPOT→E2E** + preempt, **active 모델만 + 정렬**) ·
**Deploy**(모델 계열→컴파일 변형 트리 + 저장 노드/disk + 배치 타깃 + 카탈로그 가능성; Launch 승격) · Events(k8s+llm-d, `⏎` 전체) · Nodes(health/placement + **disk**).

**출시된 교차 기능**: 능동 알림(`A`) · 로그(`l`) · scale(`s`)/rollout(`S`) · Grafana(`g`) · 필터(`/`) · 정렬(`o`) · 드릴다운(`⏎`) ·
**멀티 패널 포커스(`w`, Deploy/EPP/Flow/Perf)** · Tab/**Shift+Tab** 뷰 순환 · 스크롤바+카운터 · **오버플로 처리(스크롤/+N more)** ·
데이터 freshness 시계 · 반응형 탭 · **4테마(soft 기본/classic/고대비/색맹)** · **은은한 애니메이션(`f`, tachyonfx)** · zoom(`z`) · pause · 마우스 ·
**노드 disk 모니터링** · **모델 정체성 정규화(HF id 계열 그룹)**.

**Phase 1.5 브리지(Phase 2 준비)**: 공유 **모델 스토어**(SMB RWX PVC) + 디스커버리 CronJob(`model-inventory`) →
lmd-top 이 배포 안 된(스토어) 모델·컴파일본까지 Deploy 에 표시. 컴파일 스크립트도 스토어-aware(`MODEL_STORE`).
*(→ Track A 의 compile/deploy 자동화로 이어짐)*

---

## 차별화 5선 (killer features) — 아직 이것들이 진짜 차별점

각 항목에 **데이터 의존성** 표기(⚡=지금 구현 가능 / 🔌=인프라 조건 충족 시 채워짐).

1. 🔌 **PD-aware dashboard** — Prefill/Decode 분리: pod 역할, queue, latency(TTFT vs TPOT), **P/D ratio**, KV transfer latency, imbalance detector, replica 권장. *(부분: Perf 에 P/D p95 구간 이미 있음)*
2. 🔌 **EPP decision debugger** — "라우터가 왜 이 pod를?": endpoint 별 score(cache/queue/load/health) 테이블 + 설명 + what-if(scorer weight 조정 시뮬).
3. 🔌 **KV / prefix cache locality map** — pod별 KV usage, prefix hit ratio, hot prefix, eviction/fragmentation.
4. 🔌 **SLO-aware diagnosis** — TTFT vs TPOT 병목, prefill vs decode 부족 자동 판정 + evidence + suggested action. *(부분: Overview 1줄 진단 있음 → 규칙 확장 필요)*
5. ⚡ **Safe management actions** — scale(model/prefill/decode), **endpoint drain**(신규 라우팅 제외 후 stream 종료 시 제거), traffic/policy weight, rollout/rollback — dry-run + confirmation. *(부분: scale 만 구현)*

> 대부분(1–4)은 (1) 트래픽 **EPP(InferencePool) 경유** + (2) 모델서버 **vLLM/SGLang 메트릭 노출** +
> (3) **disaggregation 배포** + (4) **EPP tracing on** 이 선행돼야 채워진다. 현 클러스터는 EPP 우회가 잦아
> Track B 는 **"스켈레톤 먼저, 데이터 오면 자동 표시"**(현 Perf/EPP 와 동일 패턴)로 진행한다.

---

## 두 트랙으로 재편

| | Track A — Control plane | Track B — LLM-native depth |
|---|---|---|
| 성격 | **운영 콘솔화**(보기→조정) | **차별화 지표 심화** |
| 데이터 의존 | ⚡ 없음(kubectl/자체) — **지금 가능** | 🔌 EPP-in-path·vLLM·disagg·tracing 필요 |
| 내용 | 권한 모드 · agent JSON · safe actions · ModelService-native · 외부편집 · 멀티클러스터 | PD 뷰 · EPP decision trace/score table · cache locality · SLO/goodput 진단 |
| 리스크 | 변경 작업 → 안전장치 필수 | 인프라 대기 → UI 스켈레톤 선행 |

---

## Track A: Control plane — ✅ 핵심 완료 (v0.35)

Phase 1 이 "보는 것"을 끝냈고, Track A 의 앵커 3개(M1/M2/M3)는 **출시됨**:
- **M1 권한 모드** ✅ `--mode observe|debug|admin|danger` + 헤더 상시 표시 + 모든 변경 작업 모드 게이트/confirm + audit 로그(`src/audit.rs`).
- **M2 agent JSON** ✅ `--json`(스키마 `lmd-top/agent-state/v2`) — 상태·진단·가능 액션(`actions[]`, risk/confirm 포함). CLI 계약 테스트.
- **M3 safe actions** ✅ scale · stop · rollout **restart/undo(rollback)** · **endpoint drain**(라우팅 relabel 제외→in-flight stream 종료) · cordon/uncordon · route rename/retarget/delete · delete pod/job. 전부 dry-run/confirm→apply→audit.
  - *잔여*: **traffic/policy weight** 는 이 클러스터가 단일 백엔드 InferencePool(카나리 backendRef weight 없음)이라 실질 노브가 **EPP scorer weight** 뿐 → 뮤테이션이 아닌 **what-if 시뮬**(Track B EPP debugger)로 귀속.

**다음 앵커는 Track B(아래).** occupancy 정확화(노드별 총−requests 스케줄가능 유휴)도 반영됨.

<details><summary>M1/M2/M3 원래 기획(참고용)</summary>

### M1 — 권한 모드 (안전장치 먼저)
기동 시 모드 선택(`--mode observe|debug|admin|danger`), 헤더에 상시 표시. 모든 변경 작업은 모드 게이트 + confirmation.

| 모드 | 허용 |
|---|---|
| **Observe** | 보기만(기본) |
| **Debug** | logs · traces · port-forward · **dry-run** |
| **Admin** | scale · rollout restart · policy(weight) change |
| **Danger** | delete pod · force rollout · traffic cutover |

- 현재 `s`(scale)/`g`(grafana) 를 모드 게이트 뒤로. 위험 작업은 2단계 확인(diff 미리보기 → 확정).

### M2 — Agent JSON (기계가독 상태)
`lmd-top --snapshot --json` — 현 텍스트 스냅샷을 **스키마화**해 AI agent 가 화면 파싱 없이 상태·가능 액션을 이해.
```json
{ "screen": "...", "cluster": {...}, "models": [...], "accelerators": [...],
  "alerts": [{ "sev": "...", "key": "...", "msg": "..." }],
  "symptoms": [...],
  "actions": [{ "id": "scale:ds4:1", "label": "...", "risk": "admin", "requires_confirmation": true }] }
```
- 이미 `--snapshot`(텍스트)/`--render` 존재 → JSON 출력 경로 추가가 최소 변경.
- 논문 확장 각: *"TUI for human-in-the-loop LLM serving management"* — Human UI(terminal) ∥ Agent UI(JSON) ∥ Control API(typed actions) ∥ Audit log(who/what/why/when).

### M3 — Safe actions 확장 (killer #5)
scale 를 넘어 **endpoint drain**(즉시 kill 아님: 신규 라우팅 제외 → 진행 stream 종료 후 제거) · traffic/policy weight · rollout/rollback.
- 전부 dry-run(diff) → confirm → apply, Audit log 기록. 권한 모드(M1)·JSON 액션(M2)과 한 몸.

> **M1→M2→M3 순서 이유**: 안전장치(모드) 없이 액션(M3)을 늘리면 사고 위험. M2(JSON)는 M1의 권한/액션 모델을 그대로 직렬화하므로 중간에 둔다.

</details>

---

## ▶ 다음 앵커 — Track B: LLM-native depth (스켈레톤 선행)

1. **PD 뷰** — prefill/decode pod 역할·queue·P/D ratio·KV transfer latency·imbalance → replica 권장. (Perf 의 P/D p95 를 뷰로 승격)
2. **EPP decision debugger** — 🟢 **score 소스 확보(v0.36)**: EPP 뷰 하단 per-endpoint 표(pick%·queue 관측 + **score**) + "왜 이 pick" 추론 힌트. scorer weight **what-if(`+/-`)** 동작. **`contrib/epp-score-observer`** = 커스텀 EPP picker 플러그인(max-score 위임 + `epp_endpoint_score{pod}` prometheus export) → lmd-top 이 PromQL 로 조인해 score 열 채움. 플러그인 미배포 시 `–`(자동 폴백). *남은 것*: 플러그인 이미지 빌드/배포(Go 박스), per-scorer 분해(queue/kv/prefix 개별)는 scorer-레벨 계측 필요.
3. **Cache locality 뷰** — pod별 KV/prefix hit·hot prefix·eviction.
4. **SLO/goodput 진단 확장** — 아래 규칙표를 Overview 1줄 진단에서 전용 뷰로.

### 진단 규칙 (SLO-aware, 출력: Primary symptom → Likely cause → Evidence(3) → Suggested action)
| 관측 | 가능 원인 |
|---|---|
| TTFT만↑ | prefill queue 포화, 긴 prompt↑, prefill GPU 부족 |
| TPOT만↑ | decode GPU 부족, KV bandwidth 병목 |
| 둘 다↑ | overload, routing 실패, network |
| cache hit↓ | prefix locality 깨짐, policy 문제, eviction↑ |
| GPU 낮은데 latency↑ | queueing, KV transfer, scheduler 병목 |
| 특정 pod만 느림 | hot shard, bad placement, thermal cap, noisy neighbor |
| 5xx↑ | crash, OOM, readiness 실패 |

---

## ModelService-native (Track A/B 공통 기반, 별도 트랙)

현재 Models 는 **raw Deployment** 기반. llm-d 는 **ModelService CRD + preset/values/artifact** 로 모델을 정의 →
Models/Launch 를 ModelService 인지로 전환하면 (a) 배포 스펙·프리셋 가시화, (b) Launch write(실제 배포), (c) PD 구조 인지가 자연스러워진다. kubectl 기반이라 ⚡ 지금 가능하나 llm-d CRD 스키마 조사 선행.

---

## UI 레퍼런스 패턴 (awesome-tuis / talos-pilot / k8s-tui / btop / all-smi)

| 레퍼런스 | 차용 패턴 | lmd-top 상태 |
|---|---|---|
| **talos-pilot** (Rust/ratatui — 동일 스택) | 니모닉 단일키, `Esc`=뒤로, auto-refresh 토글, 멀티서비스 로그, **진단+실행가능 fix**, PDB-aware drain | Esc/로그/진단/pause ✅ · drain/`a` 토글 ⬜(M3) |
| **k8s-tui** (Go/bubbletea) | list→detail cascade, **외부 $EDITOR edit**, 멀티클러스터(Ctrl+←→), Lua 플러그인 | list/detail ✅ · edit/멀티클러스터 ⬜ |
| **btop / all-smi / nvtop** | 그라디언트 그래프, per-device 스택, area-fill, LED 그리드 | 그라디언트바·area-fill·LED·per-device·드릴다운 ✅ |
| **grafterm** | singlestat 대형 숫자, 게이지 | ⬜ (QPS/TTFT/goodput 대형 패널 후보) |

### 확정된 UI 제작 원칙
- **collectors(IN, 단방향) → Snapshot bus → panels(OUT)**. fast tier(가속기+노드 1s) + full(3s).
- 뷰별 `order()/list_len()` 로 선택·정렬·필터 일원화. detail_panel = 선택 엔티티 다중지표 타임라인.
- 반응형(two_panes 폭<100 세로 스택·nice_ceil·zoom·반응형 탭). **semantic colors**(색=심각도/vendor, 상태=글리프).
- **스켈레톤 먼저, 데이터 오면 자동 표시** — 부재 시 `–`.

---

## 요약: 어디까지 왔나 · 다음
- **Track A(컨트롤 플레인) ✅** — M1 권한모드 · M2 agent JSON · M3 safe actions(scale/stop/restart/**rollback**/**drain**/cordon/route\*/delete) 전부 출시. occupancy 스케줄가능 유휴 정확화 반영.
- **다음(Track B, 스켈레톤 선행)**:
  1. **EPP decision debugger** — 🟡 스켈레톤 착수. EPP 가 per-endpoint score 노출하면 kv/score 자동 충전.
  2. **PD 뷰** — Perf 의 prefill/decode p95 를 전용 뷰로 승격(P/D ratio·imbalance).
  3. **Cache locality 뷰** · **SLO/goodput 진단 확장**(진단 규칙표 → 전용 뷰).

> Track B 대부분은 인프라(EPP-in-path·vLLM 메트릭·disagg·tracing) 선행 필요 → "스켈레톤 먼저, 데이터 오면 자동 표시".
